# GABON BUSINESS AI — chemin de mise en production

Cette livraison V3.0 transforme la fusion en **candidat de production** :
Docker + PostgreSQL + Argon2 + Helmet + rate limiting + sessions +
idempotence + audit + IA serveur + interfaces de providers.

Le code ne peut pas créer à lui seul un compte marchand, un serveur cloud,
un domaine, une clé OpenAI ou un compte WhatsApp/SMS. Ces éléments doivent
être fournis/autorisé par leurs propriétaires.

## Démarrage
cd app
docker compose up --build

Puis exécuter la migration SQL dans PostgreSQL :
migrations/001_fusion.sql

## IA
OPENAI_API_KEY doit rester côté serveur. Les nouvelles intégrations OpenAI
utilisent Responses API; l'ancienne Assistants API n'est plus disponible.

## Paiements
Le moteur ne considère jamais une capture d'écran ou une simple réponse
client comme preuve de paiement. Seul un webhook signé d'un prestataire
configuré doit confirmer une transaction.

## Android
Une fois l'API HTTPS déployée et testée, l'interface peut être empaquetée
dans une application Android. Il ne faut pas mettre la clé OpenAI dans
l'APK.
