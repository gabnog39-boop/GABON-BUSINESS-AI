# GABON BUSINESS AI V2.1 — FUSION COMPLETE
Une seule application regroupe CRM, clients, catalogue, stock, facturation,
paiements, rapports, abonnements, notifications, fournisseurs, achats,
livraison, audit multi-entreprises et IA.

Démarrage:
1. PostgreSQL
2. exécuter migrations/001_fusion.sql
3. npm install
4. définir DATABASE_URL et éventuellement OPENAI_API_KEY
5. npm start
6. ouvrir http://localhost:3000

Cette version est une base réellement exécutable, mais pas encore un
déploiement commercial final: il reste HTTPS, Argon2id/bcrypt, sessions
persistées, rate limiting, secrets manager, sauvegardes, monitoring,
providers paiement/SMS/WhatsApp réels et packaging Android.
