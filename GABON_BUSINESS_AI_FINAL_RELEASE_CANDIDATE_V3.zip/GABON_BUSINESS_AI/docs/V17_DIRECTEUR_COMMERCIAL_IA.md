# V17 — Directeur commercial IA

## Objectif
Transformer les données commerciales en actions concrètes pour augmenter les ventes, améliorer les relances et suivre les opportunités.

## Fonctions
- pipeline commercial
- opportunités
- valeur pondérée des opportunités
- analyse des factures impayées
- recommandations de relance
- préparation de prospection
- actions commerciales proposées

## Sécurité
Le Directeur commercial IA propose les actions. Il ne doit pas envoyer un message, supprimer un client, modifier une facture ou engager un paiement sans confirmation explicite et journalisation.

## API
GET  /api/v17/commercial/:businessId/analysis
POST /api/v17/commercial/:businessId/opportunities
POST /api/v17/commercial/:businessId/actions
