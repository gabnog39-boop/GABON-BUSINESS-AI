# V30 — Multi-entreprises et multi-sites

## Exemple
Un propriétaire possède:
- Entreprise A avec Libreville et Port-Gentil;
- Entreprise B avec une seule agence.

Le compte maître peut voir une consolidation autorisée.
Un employé de l'entreprise A ne doit jamais voir les données de l'entreprise B.

## Règle de sécurité
Toute requête métier doit être contrôlée contre le périmètre d'entreprises et de sites autorisé.

## Données concernées
- clients;
- produits;
- stocks;
- ventes;
- factures;
- paiements;
- dépenses;
- fournisseurs;
- rapports;
- mémoire IA;
- notifications.

## Production
L'isolation doit être appliquée côté serveur et base de données. L'interface seule ne constitue jamais une barrière de sécurité.
