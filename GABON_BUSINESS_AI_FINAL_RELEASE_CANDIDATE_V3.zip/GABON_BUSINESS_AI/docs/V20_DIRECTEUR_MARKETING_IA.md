# V20 — Directeur Marketing IA

## Capacités
- analyse de la clientèle;
- fidélisation;
- acquisition;
- offres commerciales;
- ventes complémentaires;
- préparation de campagnes;
- préparation de messages personnalisés;
- estimation/contrôle du budget;
- recommandations marketing à partir des données de l'entreprise.

## Sécurité
Une campagne avec budget, publication externe ou engagement commercial ne doit pas être exécutée automatiquement. L'IA prépare/propose; l'utilisateur confirme.

## Limites
V20 n'intègre pas encore le fournisseur d'IA de production, les canaux externes, ni la consolidation dans un serveur canonique unique.
