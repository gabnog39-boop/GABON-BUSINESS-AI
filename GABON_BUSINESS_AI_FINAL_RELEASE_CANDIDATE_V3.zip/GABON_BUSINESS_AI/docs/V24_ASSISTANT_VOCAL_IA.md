# V24 — Assistant vocal intelligent

## Architecture
1. Capture audio côté Android/Web.
2. Transcription vocale.
3. Analyse de l'intention.
4. Extraction des paramètres.
5. Contrôle des permissions.
6. Si lecture seule: réponse.
7. Si action sensible: présentation de l'action et demande de confirmation.
8. Exécution uniquement après confirmation.
9. Journal d'audit.

## Sécurité
Une phrase comme « supprime cette facture » ou « envoie ce document » ne doit pas déclencher l'action immédiatement.

La confirmation doit être explicite et liée à la commande préparée.

## Production
À intégrer avec un service STT/TTS approprié, le serveur canonique, l'authentification et les permissions réelles.
La clé d'un fournisseur IA ne doit jamais être embarquée dans l'APK.

## Exemples de commandes
- « Donne-moi le chiffre d'affaires du mois. »
- « Quels clients ont des factures impayées ? »
- « Prépare une facture pour Jean. »
- « Envoie le devis au client. » → confirmation obligatoire.
