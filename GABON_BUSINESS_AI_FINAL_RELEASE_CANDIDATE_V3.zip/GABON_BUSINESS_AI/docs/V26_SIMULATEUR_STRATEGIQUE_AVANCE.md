# V26 — Simulateur stratégique IA avancé

## Exemples
Le dirigeant peut demander:
- « Que se passe-t-il si j'augmente mes prix de 10 % ? »
- « Et si mes ventes augmentent de 20 % ? »
- « Que se passe-t-il si j'embauche deux personnes ? »
- « Compare trois scénarios pour l'ouverture d'une nouvelle agence. »

## Méthode
Situation actuelle → hypothèses → projection → écarts → avertissements → comparaison.

Les hypothèses doivent être visibles. L'IA ne doit pas présenter une projection comme une certitude.

## Sécurité
Le simulateur ne modifie pas les données réelles de l'entreprise.
Une décision issue d'une simulation doit être validée séparément avant toute opération sensible.
