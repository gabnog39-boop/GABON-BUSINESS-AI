# V36 — Détection intelligente des anomalies

## Objectif
Aider le dirigeant à repérer rapidement les écarts inhabituels.

## Signaux actuels
- baisse ou hausse anormale des ventes;
- hausse des dépenses;
- hausse des créances;
- variation importante du stock.

## Principe important
Une anomalie est un signal statistique ou métier nécessitant une vérification. Elle ne signifie pas automatiquement fraude, erreur ou faute.

## Revue humaine
Chaque anomalie peut être:
- confirmée;
- classée sans suite;
- envoyée en investigation.

## Sécurité
Le moteur respecte le périmètre multi-entreprises/multi-sites et ne peut analyser que les données autorisées.
