# Acceptance V22

- [x] Génération structurée
- [x] Devis
- [x] Factures
- [x] Reçus
- [x] Commandes
- [x] Livraisons
- [x] Rapports
- [x] Courriers
- [x] Contrats
- [x] Calcul des totaux
- [x] Validation humaine obligatoire
- [x] Séparation GABON 360 AI
- [ ] Templates PDF production
- [ ] Signature électronique
- [ ] Envoi email/SMS/WhatsApp
- [ ] Intégration serveur canonique
- [ ] UI Android/Web
- [ ] Tests end-to-end
