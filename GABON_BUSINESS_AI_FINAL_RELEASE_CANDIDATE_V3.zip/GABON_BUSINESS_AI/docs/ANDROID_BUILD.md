# Android build final

Le projet Android est compilé par GitHub Actions avec Java 21, Android SDK 35 et Gradle 8.7.

Le workflow ne dépend pas d'un `gradlew` déjà présent : Gradle 8.7 est installé par l'action officielle avant la compilation.

## Vérifications
- structure Gradle présente
- manifeste Android présent
- sources Java présentes
- APK debug généré
- APK non vide
- APK publié comme artifact GitHub Actions

## Limite actuelle
L'URL API reste configurable et n'est pas une clé secrète embarquée dans l'APK. Le backend de production doit être déployé et son URL réelle injectée avant utilisation métier en production.

Aucun module territorial, cartographique, satellite, parc, conservation ou GABON 360 AI n'est inclus dans ce projet.
