# V37 — Centre de pilotage IA

## Vue dirigeant
Le centre rassemble dans une seule vue:
- score de santé;
- chiffre d'affaires;
- encaissements;
- créances;
- dépenses;
- alertes de stock;
- anomalies;
- opportunités;
- notifications.

## Priorisation
Les informations critiques et importantes sont placées en premier.

## Brief exécutif
Une synthèse courte peut être présentée au dirigeant:
1. situation générale;
2. priorités;
3. recommandations.

## Sécurité
Le centre ne contourne aucun contrôle. Il ne voit que les entreprises et sites autorisés.

## Principe
Le centre de pilotage orchestre les informations; les modules spécialisés restent responsables de leurs propres règles métier.
