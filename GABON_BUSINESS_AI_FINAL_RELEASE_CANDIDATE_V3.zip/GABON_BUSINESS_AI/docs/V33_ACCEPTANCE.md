# Acceptance V33

- [x] Préparation de négociation
- [x] Prix cible et prix minimum
- [x] Contrôle de marge
- [x] Stratégies de négociation
- [x] Gestion des objections
- [x] Validation humaine
- [x] Isolation multi-entreprises
- [x] Exclusion GABON 360 AI
- [ ] Connexion au serveur canonique
- [ ] Connexion aux données commerciales réelles
- [ ] IA générative côté serveur
- [ ] Interface Android/Web
- [ ] Tests end-to-end
