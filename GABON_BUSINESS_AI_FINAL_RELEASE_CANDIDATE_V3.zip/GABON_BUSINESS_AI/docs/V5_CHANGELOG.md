# V5 — changements

- Fusion de la base V4 dans un paquet MASTER.
- Conservation des archives sources V3/V4 dans `history/source`.
- Remplacement du hachage SHA-256 par Argon2id pour les mots de passe.
- Contrôle serveur d'abonnement sur les routes métier.
- Nouveau statut d'abonnement consultable avant paiement.
- Accès aux offres et à la demande d'abonnement sans abonnement actif.
- Expiration d'abonnement : blocage métier, données conservées.
- Cloisonnement BUSINESS AI / GABON 360 explicite.
