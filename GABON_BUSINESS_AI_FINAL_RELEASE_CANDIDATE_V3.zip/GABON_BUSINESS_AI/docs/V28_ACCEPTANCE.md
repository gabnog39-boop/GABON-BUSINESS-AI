# Acceptance V28

- [x] Règles d'automatisation
- [x] Déclencheurs planifiés
- [x] Alerte stock
- [x] Factures échues
- [x] Rapports périodiques
- [x] Tâches
- [x] Proposition d'exécution
- [x] Confirmation pour actions sensibles
- [x] Journal d'exécution
- [x] Exclusion GABON 360 AI
- [ ] Scheduler production
- [ ] Serveur canonique
- [ ] Intégration V11–V27
- [ ] Notifications Android/Web
- [ ] Tests end-to-end
