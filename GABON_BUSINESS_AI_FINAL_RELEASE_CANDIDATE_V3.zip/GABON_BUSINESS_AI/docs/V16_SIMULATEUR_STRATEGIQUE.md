# V16 — Simulateur stratégique « Et si ? »

Le simulateur permet de comparer une situation de référence à un scénario hypothétique.

## Exemples
- hausse des prix de 10 %
- baisse des ventes de 20 %
- hausse/baisse des volumes
- hausse des dépenses
- ajout de coûts fixes
- combinaison de plusieurs hypothèses

## Prudence
Les résultats sont des simulations de gestion fondées sur les données disponibles et les hypothèses saisies. Ils ne constituent pas une garantie, une prévision certaine ni un conseil financier certifié.

## API
POST /api/v16/scenarios/:businessId
GET  /api/v16/scenarios/:businessId

## Sécurité
Chaque scénario est rattaché à une entreprise. Aucun scénario ne peut accéder aux données d'une autre entreprise.
