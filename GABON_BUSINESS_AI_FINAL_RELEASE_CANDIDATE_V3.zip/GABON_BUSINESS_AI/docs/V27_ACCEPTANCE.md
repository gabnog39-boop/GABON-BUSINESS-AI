# Acceptance V27

- [x] Orchestrateur central
- [x] Détection du domaine
- [x] Finance
- [x] Commercial
- [x] Stock
- [x] Marketing
- [x] Documents
- [x] Mémoire
- [x] Stratégie
- [x] Confirmation des actions sensibles
- [x] Contexte limité par domaine
- [x] Historique contractuel
- [x] Exclusion GABON 360 AI
- [ ] Intégration réelle V13–V26
- [ ] Fournisseur IA production
- [ ] Serveur canonique
- [ ] Android/Web
- [ ] Tests end-to-end
