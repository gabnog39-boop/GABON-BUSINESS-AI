# V15 — Automatisation intelligente

## Contrat API
POST /api/v15/automation/rules/:businessId
POST /api/v15/automation/rules/:businessId/:ruleId/propose
POST /api/v15/automation/runs/:businessId/:runId/confirm

## Automatisations initiales
- relance client à préparer
- alerte de stock
- génération de rapport
- rappel d'échéance
- création de tâche

## Sécurité
Une automatisation ne peut pas :
- envoyer de l'argent automatiquement ;
- supprimer des données ;
- modifier les droits d'un utilisateur ;
- modifier un abonnement/paiement ;
- produire une action irréversible sans confirmation.

Toutes les exécutions doivent être liées à l'entreprise concernée et journalisables.
