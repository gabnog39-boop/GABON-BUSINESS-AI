# V39 — Finalisation technique

## Done
- Canonical Node/Express API entrypoint.
- Server-side bearer sessions.
- Business tenant checks.
- Subscription gate on paid business modules.
- Platform-owner access is separate from a business OWNER.
- Android API client and session persistence.
- Payment webhook is fail-closed until a real provider signature/verification is configured.
- No GABON 360 / territorial functionality.

## Required before release
1. Deploy PostgreSQL and run migrations in order.
2. Set `DATABASE_URL`.
3. Set a real `PLATFORM_OWNER_USER_ID`.
4. Deploy the API behind HTTPS.
5. Configure a real payment provider and verify webhook signatures server-side.
6. Set Android `API_BASE_URL` to the deployed HTTPS API.
7. Build and test the signed APK/AAB on Android devices.
8. Run end-to-end tests for registration, paid access, expiry, tenant isolation and payment callbacks.

The project must not claim production readiness until these gates pass.
