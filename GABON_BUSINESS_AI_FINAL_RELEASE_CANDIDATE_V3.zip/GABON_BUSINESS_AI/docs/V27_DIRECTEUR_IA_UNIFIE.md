# V27 — Directeur IA unifié

## Principe
Un seul assistant central coordonne les spécialistes internes.

Exemple:
« Mes ventes baissent et plusieurs clients me doivent de l'argent. Que dois-je faire ? »

Le Directeur peut mobiliser Commercial + Finance + Mémoire, puis produire une réponse unifiée.

## Sécurité
Le Directeur ne contourne jamais:
- les permissions;
- l'abonnement;
- l'isolation des entreprises;
- la confirmation humaine;
- le journal d'audit.

## Contexte minimal
Le Directeur ne doit transmettre à un spécialiste que les données nécessaires à la demande.

## Production
Cette couche doit être branchée au serveur canonique et aux services V13–V26. Elle ne remplace pas ces services; elle les orchestre.
