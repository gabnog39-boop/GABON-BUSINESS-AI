# V31 — Benchmarking intelligent

## Objectif
Permettre au propriétaire et aux utilisateurs autorisés de comparer des entreprises/sites sur des indicateurs de gestion.

## Indicateurs
- chiffre d'affaires;
- dépenses;
- marge;
- créances;
- alertes de stock;
- nombre de ventes.

## Confidentialité
Le benchmark ne peut utiliser que les business_id présents dans le périmètre autorisé du compte. Aucune donnée d'une entreprise étrangère n'est récupérée ou révélée.

## Interprétation
Le benchmark sert à piloter l'activité. Il ne constitue ni un audit comptable certifié ni une notation financière officielle.

## Cas d'usage
- comparer deux agences d'une même entreprise;
- comparer plusieurs entreprises appartenant au même propriétaire;
- comparer les périodes d'une même entreprise;
- détecter un site en baisse;
- identifier les meilleures performances et les écarts.
