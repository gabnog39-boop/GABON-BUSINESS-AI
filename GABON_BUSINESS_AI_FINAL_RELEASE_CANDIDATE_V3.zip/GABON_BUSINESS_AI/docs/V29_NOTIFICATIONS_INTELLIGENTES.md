# V29 — Notifications intelligentes

## Priorités
- CRITICAL: problème nécessitant une attention immédiate;
- HIGH: action importante;
- NORMAL: information utile;
- LOW: information non urgente.

## Intelligence
Le moteur:
1. reçoit l'événement métier;
2. construit la notification;
3. vérifie les préférences;
4. détecte les doublons;
5. choisit le canal;
6. classe la notification;
7. journalise la distribution.

## Multicanal
IN_APP, PUSH, EMAIL, SMS et WEBHOOK sont prévus.
Les intégrations externes seront ajoutées côté serveur, jamais avec des secrets embarqués dans l'APK.

## Production
Il faudra brancher un scheduler, un fournisseur email/SMS/push, des quotas, du rate limiting et un système de reprise en cas d'échec.
