# Acceptance V29

- [x] Notifications métier
- [x] Priorités
- [x] Préférences utilisateur
- [x] Détection des doublons
- [x] Classement intelligent
- [x] Canaux IN_APP/EMAIL/SMS/PUSH/WEBHOOK prévus
- [x] Historique et statut
- [x] Exclusion GABON 360 AI
- [ ] Fournisseurs externes production
- [ ] Push Android/Web production
- [ ] Scheduler
- [ ] Serveur canonique
- [ ] Tests end-to-end
