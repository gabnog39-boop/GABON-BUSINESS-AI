# V18 — Directeur Finance IA

## Mission
Analyser la situation financière de gestion de l'entreprise et signaler les points nécessitant une attention.

## Indicateurs
- encaissements
- dépenses
- achats
- facturation
- créances estimées
- résultat opérationnel estimé
- couverture des sorties par les encaissements

## Alertes
- créances clients
- pression de trésorerie
- résultat de gestion négatif

## Important
V18 est un outil de pilotage. Il ne remplace pas un expert-comptable, une comptabilité légalement certifiée ou un conseil financier professionnel.

## API
GET  /api/v18/finance/:businessId/analysis
POST /api/v18/finance/:businessId/alerts
