# Acceptance V20

- [x] Directeur Marketing IA défini
- [x] Acquisition
- [x] Fidélisation
- [x] Cross-sell
- [x] Campagnes
- [x] Contrôle humain des dépenses
- [x] Séparation stricte avec GABON 360 AI
- [ ] Intégration serveur canonique
- [ ] Connecteurs SMS/email/WhatsApp
- [ ] Tests end-to-end
- [ ] UI Android/Web
