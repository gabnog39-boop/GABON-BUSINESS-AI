# V25 — Score de santé de l'entreprise

Dimensions: trésorerie, rentabilité, créances, ventes, stock, dépenses, objectifs et activité commerciale.

Niveaux:
- 80–100 EXCELLENT
- 65–79.99 GOOD
- 50–64.99 WATCH
- 35–49.99 RISK
- 0–34.99 CRITICAL

Le score doit toujours être accompagné des indicateurs sources. Le Directeur IA peut proposer des actions, mais les opérations sensibles restent soumises à confirmation humaine.
