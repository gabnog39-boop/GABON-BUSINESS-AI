# V35 — Prévision intelligente des ventes

## Objectif
Donner au dirigeant une estimation structurée de l'activité future à partir des données disponibles.

## Scénarios
- PRUDENT;
- CENTRAL;
- DYNAMIQUE.

## Contrôle
La projection doit être recalculée lorsque de nouvelles données réelles arrivent.

## Limites
Le moteur actuel est une base de projection par scénario et ne constitue pas une garantie, un audit ou un modèle financier certifié.

La future intégration pourra utiliser davantage de signaux: saisonnalité, historique mensuel, produits, clients, campagnes, événements commerciaux et objectifs.
