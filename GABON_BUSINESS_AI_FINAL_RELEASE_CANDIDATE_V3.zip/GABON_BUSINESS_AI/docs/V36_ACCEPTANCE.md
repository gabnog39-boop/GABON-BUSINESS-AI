# Acceptance V36

- [x] Détection baisse des ventes
- [x] Détection hausse des ventes
- [x] Détection hausse dépenses
- [x] Détection hausse créances
- [x] Détection variation stock
- [x] Score de gravité
- [x] Explication et preuves utilisées
- [x] Revue humaine
- [x] Isolation business/site
- [x] Exclusion GABON 360 AI
- [ ] Détection statistique avancée
- [ ] Connexion au serveur canonique
- [ ] Connexion aux données réelles V11-V35
- [ ] Interface Android/Web
- [ ] Tests end-to-end
