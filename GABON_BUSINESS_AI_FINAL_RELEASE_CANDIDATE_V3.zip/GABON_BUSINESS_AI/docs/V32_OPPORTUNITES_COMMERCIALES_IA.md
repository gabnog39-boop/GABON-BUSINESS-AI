# V32 — Opportunités commerciales IA

## Fonctionnement
L'IA examine uniquement les données du périmètre autorisé et recherche notamment:
- clients inactifs avec historique;
- produits à forte demande et stock faible;
- possibilités de ventes croisées;
- possibilités d'upsell;
- nouveaux produits/services à tester;
- pistes d'expansion par site.

## Contrôle humain
Une opportunité est d'abord PROPOSED. Elle peut être APPROVED ou REJECTED par un utilisateur autorisé.

L'approbation d'une opportunité ne doit pas déclencher automatiquement une dépense, un achat, une campagne payante ou un message externe. Ces actions restent soumises aux contrôles des modules concernés.

## Confidentialité
Toutes les requêtes doivent appliquer l'isolation business_id/site_id du modèle multi-tenant V30.

## Limites
Les estimations de valeur et de confiance sont des indicateurs de gestion, pas des garanties de chiffre d'affaires.
