# GABON BUSINESS AI — V13

## Ajouts
- Tableau de bord intelligent consolidé
- Rapports métier persistants
- Mémoire professionnelle IA par entreprise
- Objectifs intelligents de l'entreprise
- Contrat d'API V13

## Règles
- Isolation stricte par entreprise.
- Les données de mémoire IA restent propres à l'entreprise.
- Aucun contenu territorial, satellite, drone, parc, forêt, SIG ou GABON 360.
- Le tableau de bord financier reste un indicateur de gestion et ne remplace pas une comptabilité légalement certifiée.

## État
V13 est une couche backend/architecture. Elle doit encore être branchée au serveur canonique, à l'authentification réelle, au contrôle d'abonnement et aux interfaces Android/Web.
