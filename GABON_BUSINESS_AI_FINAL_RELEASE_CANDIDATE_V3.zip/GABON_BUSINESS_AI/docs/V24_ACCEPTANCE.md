# Acceptance V24

- [x] Commandes vocales structurées
- [x] Transcription comme entrée
- [x] Classification lecture seule / sensible
- [x] Préparation d'action
- [x] Confirmation obligatoire pour actions sensibles
- [x] Refus d'une commande
- [x] Historique contractuel
- [x] Exclusion GABON 360 AI
- [ ] STT production
- [ ] TTS production
- [ ] Intégration Android
- [ ] Intégration Web
- [ ] Serveur canonique
- [ ] Tests end-to-end
