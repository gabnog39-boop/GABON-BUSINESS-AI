# Acceptance V23

- [x] Mémoire structurée
- [x] Isolation par entreprise
- [x] Types de mémoire
- [x] Contexte IA limité
- [x] Désactivation d'une mémoire
- [x] Contrôle business_id
- [x] Routes contractuelles
- [x] Exclusion GABON 360 AI
- [ ] Intégration serveur canonique
- [ ] Interface Android/Web
- [ ] Audit complet
- [ ] Tests end-to-end
- [ ] Politique de conservation production
