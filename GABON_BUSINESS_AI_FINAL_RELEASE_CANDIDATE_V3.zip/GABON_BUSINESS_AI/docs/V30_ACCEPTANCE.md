# Acceptance V30

- [x] Plusieurs entreprises
- [x] Plusieurs sites par entreprise
- [x] Accès par utilisateur
- [x] Rôles multi-entreprises
- [x] Contrôle du périmètre
- [x] Consolidation autorisée
- [x] Séparation des sites
- [x] Exclusion GABON 360 AI
- [ ] Migration des données existantes
- [ ] Intégration serveur canonique
- [ ] Dashboard Android/Web
- [ ] Tests d'isolation end-to-end
- [ ] Audit de sécurité multi-tenant
