# Acceptance V31

- [x] Benchmark multi-entreprises autorisé
- [x] Benchmark multi-sites
- [x] Indicateurs normalisés
- [x] Classements
- [x] Écarts par rapport à la moyenne
- [x] Contrôle du périmètre autorisé
- [x] Historique des snapshots
- [x] Confidentialité par business_id
- [x] Exclusion GABON 360 AI
- [ ] Connexion aux données V13-V30 dans le serveur canonique
- [ ] Tests d'isolation end-to-end
- [ ] Interface Android/Web
- [ ] Tests de performance
