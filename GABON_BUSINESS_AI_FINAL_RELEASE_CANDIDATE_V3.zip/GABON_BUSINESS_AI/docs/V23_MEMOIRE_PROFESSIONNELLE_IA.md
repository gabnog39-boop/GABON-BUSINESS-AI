# V23 — Mémoire professionnelle IA

## Fonction
GABON BUSINESS AI peut conserver les éléments métier utiles au fonctionnement de l'entreprise dans la durée.

### Exemples
- préférence de présentation des factures;
- objectif mensuel;
- procédure interne;
- décision commerciale;
- contexte d'un client;
- informations utiles sur un produit;
- instruction donnée à l'assistant.

## Isolation
La clé fondamentale est `business_id`.
Une mémoire appartient à une seule entreprise et ne doit jamais être injectée dans le contexte d'une autre.

## Sécurité
- contrôle du tenant avant lecture/écriture;
- désactivation plutôt que suppression aveugle;
- journalisation des opérations sensibles;
- possibilité de demander à l'IA de ne pas utiliser une mémoire;
- aucune donnée territoriale de GABON 360 AI.

## Production
À intégrer au serveur canonique, à l'authentification réelle et au moteur IA.
Les données sensibles doivent avoir des règles de conservation adaptées.
