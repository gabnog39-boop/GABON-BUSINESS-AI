# Acceptance V35

- [x] Projection du chiffre d'affaires
- [x] Projection du nombre de ventes
- [x] Scénarios prudent/central/dynamique
- [x] Écart avec l'objectif
- [x] Détection des risques
- [x] Recommandations
- [x] Contrôle business/site
- [x] Exclusion GABON 360 AI
- [ ] Modèle statistique avancé
- [ ] Saisonnalité réelle
- [ ] Connexion au serveur canonique
- [ ] Connexion aux données V11-V34
- [ ] Interface Android/Web
- [ ] Tests end-to-end
