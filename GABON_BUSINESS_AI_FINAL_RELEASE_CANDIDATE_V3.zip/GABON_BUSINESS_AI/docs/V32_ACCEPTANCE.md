# Acceptance V32

- [x] Détection d'opportunités
- [x] Cross-sell
- [x] Fidélisation
- [x] Opportunités liées au stock
- [x] Nouveaux produits/services
- [x] Priorités et niveau de confiance
- [x] Approbation/rejet humain
- [x] Contrôle business/site
- [x] Exclusion GABON 360 AI
- [ ] Connexion au serveur canonique
- [ ] Connexion réelle aux données V11-V31
- [ ] Interface Android/Web
- [ ] Tests end-to-end
- [ ] Intégration IA générative côté serveur
