# V14 — Directeur IA

## API contract
GET  /api/v14/director/:businessId/analysis
POST /api/v14/director/:businessId/command

## Command safety
The Director IA can propose and prepare actions.
It must not silently:
- send money
- delete business data
- alter subscription/payment status
- issue irreversible documents
- change user permissions

Sensitive actions require explicit confirmation and must be logged.

## Intelligence
The Director IA uses:
- dashboard indicators
- business memory
- financial signals
- future CRM/stock/sales signals

The production version should connect this layer to a server-side AI provider.
No AI API secret belongs in the Android APK.
