# V33 — Assistant de négociation IA

## Capacités
- préparation d'une négociation;
- définition d'un objectif et d'un prix cible;
- protection d'un prix minimum;
- analyse de marge;
- préparation d'arguments de valeur;
- réponses structurées aux objections;
- stratégie relationnelle ou orientée prix.

## Sécurité commerciale
L'IA ne peut pas:
- accepter seule une remise;
- signer un contrat;
- engager une dépense;
- modifier une facture;
- envoyer une offre engageante sans confirmation.

Toute action sensible doit passer par l'autorisation humaine et les contrôles du serveur.

## Confidentialité
Les sessions sont strictement rattachées au business_id autorisé.
