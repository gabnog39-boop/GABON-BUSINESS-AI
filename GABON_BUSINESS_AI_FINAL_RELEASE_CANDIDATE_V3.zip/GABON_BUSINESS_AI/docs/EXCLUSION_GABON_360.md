# Cloisonnement de projet

GABON BUSINESS AI et GABON 360 AI sont deux projets indépendants.

Interdits dans BUSINESS AI : satellite, drones, SIG/GIS, cartographie territoriale, parcs nationaux, forêts, biodiversité, conservation, surveillance territoriale, missions de terrain, données géospatiales, navigation terrain, océan/côte et centre national de situation.

Un concept SaaS générique peut être réutilisé uniquement s'il est indépendant de ces domaines et validé pour BUSINESS AI.
