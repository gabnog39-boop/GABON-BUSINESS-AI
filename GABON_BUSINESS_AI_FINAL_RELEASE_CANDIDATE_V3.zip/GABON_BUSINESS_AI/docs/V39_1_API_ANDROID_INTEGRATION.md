# V39.1 — API canonique + Android

## Réalisé
- Serveur canonique unique avec Helmet et limitation de débit.
- Inscription, connexion, session Bearer, déconnexion et profil.
- Isolation par entreprise via business membership.
- Dashboard, clients et produits accessibles depuis Android.
- Migration `sessions` ajoutée au schéma canonique.
- Aucune fonctionnalité GABON 360 / territoriale.

## Avant production
1. Déployer PostgreSQL + appliquer `backend/db/schema.sql`.
2. Déployer le backend en HTTPS.
3. Remplacer `API_BASE_URL` dans `android/app/build.gradle` par l'URL réelle du backend.
4. Intégrer un prestataire de paiement réel et faire vérifier l'abonnement côté serveur avant les fonctions payantes.
5. Brancher le fournisseur IA côté serveur; aucune clé IA dans l'APK.
6. Tester inscription, isolation multi-entreprise, expiration abonnement, paiement, sauvegarde et restauration.
