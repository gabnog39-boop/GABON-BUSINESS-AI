# Android V39

Le projet contient maintenant un vrai module Android Gradle.

## Principes
- Android est le client mobile officiel de GABON BUSINESS AI.
- Il communique avec le backend canonique V39.
- Aucune clé IA ou clé de paiement n'est embarquée dans l'APK.
- L'URL du backend doit être configurée avant production.
- La version actuelle est une base Android compilable, pas encore l'application métier complète.

## Avant APK final
- connecter authentification/session ;
- connecter dashboard, clients, produits, ventes, finance, IA, notifications ;
- configurer l'URL HTTPS de production ;
- tests sur plusieurs versions Android ;
- signature release ;
- tests paiement/abonnement.
