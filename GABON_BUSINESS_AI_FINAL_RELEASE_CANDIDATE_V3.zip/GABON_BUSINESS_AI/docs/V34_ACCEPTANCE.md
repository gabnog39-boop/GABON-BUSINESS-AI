# Acceptance V34

- [x] Score de fidélité
- [x] Score de valeur
- [x] Score de risque d'inactivité
- [x] Analyse récence/fréquence
- [x] Segmentation client
- [x] Actions recommandées
- [x] Isolation multi-entreprises
- [x] Exclusion GABON 360 AI
- [ ] Connexion au serveur canonique
- [ ] Connexion aux données de ventes réelles
- [ ] IA générative côté serveur
- [ ] Interface Android/Web
- [ ] Tests end-to-end
