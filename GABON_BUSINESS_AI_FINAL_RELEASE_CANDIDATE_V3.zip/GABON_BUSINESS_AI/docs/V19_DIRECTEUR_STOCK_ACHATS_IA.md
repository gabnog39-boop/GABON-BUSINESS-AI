# V19 — Directeur Stock & Achats IA

## Mission
Analyser les stocks et les ventes récentes pour détecter les risques de rupture et proposer des réapprovisionnements.

## Intelligence
- stock actuel
- seuil de stock bas
- ventes des 30 derniers jours
- moyenne quotidienne des ventes
- couverture estimée en jours
- proposition de quantité à réapprovisionner
- priorité urgence/élevée

## Sécurité
V19 propose les achats mais ne passe pas automatiquement une commande fournisseur. Une validation humaine est requise avant toute commande ou dépense.

## API
GET  /api/v19/stock/:businessId/analysis
POST /api/v19/stock/:businessId/recommendations
