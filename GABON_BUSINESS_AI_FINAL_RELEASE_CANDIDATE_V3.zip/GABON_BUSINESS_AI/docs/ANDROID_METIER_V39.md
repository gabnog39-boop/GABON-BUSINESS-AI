# Android métier V39

Le client Android contient maintenant une navigation métier de base :
- Tableau de bord
- Clients
- Produits & Stock
- Ventes & Factures
- Finance
- Directeur IA

Cette étape prépare le câblage des écrans vers les API du backend canonique.
L'URL `ApiConfig.BASE_URL` est volontairement un placeholder et doit être remplacée
par l'URL HTTPS réelle avant une release. Aucune clé secrète n'est embarquée.

Statut : interface métier intégrée, connexion API réelle et authentification encore à finaliser.
