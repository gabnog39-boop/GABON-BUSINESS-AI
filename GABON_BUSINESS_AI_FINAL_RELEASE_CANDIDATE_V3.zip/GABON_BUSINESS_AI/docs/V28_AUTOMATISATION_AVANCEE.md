# V28 — Automatisation intelligente avancée

## Exemples

### Relance
Si une facture devient échue:
→ préparer une relance client.

### Stock
Si un produit passe sous son seuil:
→ créer une alerte.

### Reporting
Chaque fin de mois:
→ préparer le rapport mensuel.

### Action sensible
Si une règle propose une commande fournisseur ou un envoi externe:
→ proposition → contrôle → confirmation humaine → exécution.

## Principes
- règles propres à chaque entreprise;
- permissions respectées;
- journal d'exécution;
- aucune modification silencieuse;
- désactivation possible;
- séparation stricte des tenants.

V28 est une fondation technique; le moteur doit être branché au serveur canonique avant la production.
