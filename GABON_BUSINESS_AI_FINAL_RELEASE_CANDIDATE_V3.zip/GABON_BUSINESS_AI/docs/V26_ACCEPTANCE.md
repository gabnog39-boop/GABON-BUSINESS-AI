# Acceptance V26

- [x] Simulation prix
- [x] Simulation volume
- [x] Simulation chiffre d'affaires
- [x] Simulation dépenses
- [x] Nouveaux coûts fixes
- [x] Projection du résultat
- [x] Projection de marge
- [x] Avertissements
- [x] Comparaison de scénarios
- [x] Aucune modification automatique des données réelles
- [x] Exclusion GABON 360 AI
- [ ] Connexion au dashboard réel
- [ ] Interface Android/Web
- [ ] Serveur canonique
- [ ] Tests end-to-end
