# V34 — Score client IA

## Indicateurs
Le moteur combine notamment:
- récence;
- fréquence;
- valeur d'achat;
- panier moyen;
- risque d'inactivité.

## Segments
- VIP;
- FIDÈLE;
- À DÉVELOPPER;
- À RÉACTIVER;
- NOUVEAU;
- STANDARD.

## Utilisation
L'IA peut recommander une relance, une fidélisation ou une vente croisée.

Aucune communication externe, remise ou action commerciale engageante ne doit être déclenchée automatiquement par le score.

## Confidentialité
Le score est strictement isolé par entreprise et client autorisé.
