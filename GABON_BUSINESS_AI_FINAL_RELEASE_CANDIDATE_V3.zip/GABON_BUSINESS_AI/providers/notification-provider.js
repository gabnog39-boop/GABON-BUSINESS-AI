class NotificationProvider {
  async send(){throw new Error("Notification provider not configured")}
}
module.exports={NotificationProvider};
