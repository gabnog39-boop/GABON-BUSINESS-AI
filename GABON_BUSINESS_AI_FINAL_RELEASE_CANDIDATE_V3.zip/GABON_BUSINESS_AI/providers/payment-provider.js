class PaymentProvider {
  async createCheckout(){throw new Error("Payment provider not configured")}
  verifyWebhook(){throw new Error("Payment provider not configured")}
}
module.exports={PaymentProvider};
