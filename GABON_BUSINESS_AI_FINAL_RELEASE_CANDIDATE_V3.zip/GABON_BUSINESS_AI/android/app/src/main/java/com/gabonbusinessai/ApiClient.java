package com.gabonbusinessai;

import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import org.json.JSONObject;

public final class ApiClient {
    public interface Callback { void done(String body, int code, Exception error); }
    private ApiClient() {}
    public static void postJson(String path, JSONObject payload, String token, Callback cb) { request("POST", path, payload, token, cb); }
    public static void get(String path, String token, Callback cb) { request("GET", path, null, token, cb); }
    private static void request(String method, String path, JSONObject payload, String token, Callback cb) {
        new Thread(() -> {
            HttpURLConnection c=null;
            try {
                URL u=new URL(ApiConfig.BASE_URL + path); c=(HttpURLConnection)u.openConnection();
                c.setRequestMethod(method); c.setConnectTimeout(10000); c.setReadTimeout(15000); c.setRequestProperty("Accept","application/json");
                if(token!=null && !token.isEmpty()) c.setRequestProperty("Authorization","Bearer "+token);
                if(payload!=null){ c.setDoOutput(true); c.setRequestProperty("Content-Type","application/json"); try(OutputStream os=c.getOutputStream()){os.write(payload.toString().getBytes(StandardCharsets.UTF_8));}}
                int code=c.getResponseCode(); InputStream is=code>=400?c.getErrorStream():c.getInputStream();
                String body=""; if(is!=null) try(BufferedReader r=new BufferedReader(new InputStreamReader(is,StandardCharsets.UTF_8))){String line;StringBuilder b=new StringBuilder();while((line=r.readLine())!=null)b.append(line);body=b.toString();}
                cb.done(body,code,null);
            } catch(Exception e){cb.done(null,-1,e);} finally {if(c!=null)c.disconnect();}
        }).start();
    }
}
