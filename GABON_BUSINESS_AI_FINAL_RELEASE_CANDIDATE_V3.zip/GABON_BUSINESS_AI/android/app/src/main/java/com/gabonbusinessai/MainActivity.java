package com.gabonbusinessai;

import android.os.Bundle;
import android.content.SharedPreferences;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import org.json.JSONArray;
import org.json.JSONObject;

public class MainActivity extends AppCompatActivity {
    private TextView content, status;
    private EditText email, password, businessName;
    private String token = "", businessId = "";
    private SharedPreferences prefs;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);
        prefs = getSharedPreferences("gba_session", MODE_PRIVATE);
        token = prefs.getString("token", "");
        businessId = prefs.getString("businessId", "");

        content = findViewById(R.id.content);
        status = findViewById(R.id.status);
        email = findViewById(R.id.email);
        password = findViewById(R.id.password);
        businessName = findViewById(R.id.businessName);

        if (!token.isEmpty()) status.setText("Session locale restaurée");

        findViewById(R.id.btnRegister).setOnClickListener(v -> register());
        findViewById(R.id.btnLogin).setOnClickListener(v -> login());
        findViewById(R.id.btnDashboard).setOnClickListener(v -> dashboard());
        findViewById(R.id.btnCustomers).setOnClickListener(v -> customers());
        findViewById(R.id.btnProducts).setOnClickListener(v -> products());
        findViewById(R.id.btnSales).setOnClickListener(v -> show("Ventes & factures", "Module commercial : devis, factures et paiements. La connexion complète au serveur sera activée avec les routes commerciales finales."));
        findViewById(R.id.btnFinance).setOnClickListener(v -> show("Finance", "Recettes, dépenses, fournisseurs et indicateurs financiers."));
        findViewById(R.id.btnAI).setOnClickListener(v -> show("Directeur IA", "L'IA analyse les données de l'entreprise et demande une confirmation avant les actions sensibles."));
    }

    private void register() {
        try {
            JSONObject p = new JSONObject()
                    .put("email", email.getText().toString())
                    .put("password", password.getText().toString())
                    .put("businessName", businessName.getText().toString());
            ApiClient.postJson("/api/auth/register", p, null,
                    (body, code, e) -> handleAuth(body, code, e, true));
        } catch (Exception e) { show("Erreur", e.getMessage()); }
    }

    private void login() {
        try {
            JSONObject p = new JSONObject()
                    .put("email", email.getText().toString())
                    .put("password", password.getText().toString());
            ApiClient.postJson("/api/auth/login", p, null,
                    (body, code, e) -> handleAuth(body, code, e, false));
        } catch (Exception e) { show("Erreur", e.getMessage()); }
    }

    private void handleAuth(String body, int code, Exception e, boolean registration) {
        runOnUiThread(() -> {
            if (e != null) {
                status.setText("API indisponible : " + e.getMessage());
                return;
            }
            try {
                JSONObject o = new JSONObject(body == null ? "{}" : body);
                if (code >= 400) {
                    status.setText("Erreur " + code + " : " + o.optString("error", "ERREUR_API"));
                    return;
                }
                token = o.getJSONObject("session").getString("token");
                if (o.has("business")) {
                    businessId = o.getJSONObject("business").getString("id");
                    saveSession();
                    status.setText(registration ? "Entreprise créée. Abonnement en attente de paiement." : "Connexion réussie");
                    dashboard();
                } else {
                    saveTokenOnly();
                    loadBusinessAndContinue();
                }
            } catch (Exception x) {
                status.setText("Réponse API invalide");
            }
        });
    }

    private void loadBusinessAndContinue() {
        ApiClient.get("/api/businesses", token, (body, code, e) -> runOnUiThread(() -> {
            if (e != null || code >= 400) {
                status.setText("Impossible de charger l'entreprise");
                return;
            }
            try {
                JSONArray a = new JSONObject(body).optJSONArray("businesses");
                if (a == null || a.length() == 0) {
                    status.setText("Aucune entreprise associée");
                    return;
                }
                businessId = a.getJSONObject(0).getString("id");
                saveSession();
                status.setText("Connexion réussie");
                dashboard();
            } catch (Exception x) {
                status.setText("Données entreprise invalides");
            }
        }));
    }

    private void saveTokenOnly() {
        prefs.edit().putString("token", token).apply();
    }

    private void saveSession() {
        prefs.edit().putString("token", token).putString("businessId", businessId).apply();
    }

    private void dashboard() {
        if (!ready()) return;
        ApiClient.get("/api/dashboard/" + businessId, token,
                (body, code, e) -> runOnUiThread(() -> {
                    if (e != null) {
                        show("Tableau de bord", "API indisponible");
                    } else if (code == 402) {
                        show("Abonnement", "Le compte est créé, mais le paiement et l'activation de l'abonnement sont nécessaires pour accéder aux fonctions métier.");
                    } else {
                        show("Tableau de bord", body == null ? "Réponse vide" : body);
                    }
                }));
    }

    private void customers() {
        if (!ready()) return;
        ApiClient.get("/api/customers/" + businessId, token,
                (body, code, e) -> runOnUiThread(() -> show("Clients", e == null ? body : "API indisponible")));
    }

    private void products() {
        if (!ready()) return;
        ApiClient.get("/api/products/" + businessId, token,
                (body, code, e) -> runOnUiThread(() -> show("Produits & Stock", e == null ? body : "API indisponible")));
    }

    private boolean ready() {
        if (token.isEmpty() || businessId.isEmpty()) {
            show("Connexion", "Connecte-toi d'abord.");
            return false;
        }
        return true;
    }

    private void show(String title, String details) {
        content.setText(title + "\n\n" + details + "\n\nAPI : " + ApiConfig.BASE_URL);
    }
}
