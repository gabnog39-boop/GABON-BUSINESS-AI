package com.gabonbusinessai;

public final class ApiConfig {
    private ApiConfig() {}
    // Release build must replace this with the real HTTPS API URL.
    public static final String BASE_URL = BuildConfig.API_BASE_URL;
}
