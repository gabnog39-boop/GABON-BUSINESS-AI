# Passage au réel

## Déjà préparé dans V3
- PostgreSQL persistant
- Docker
- séparation multi-entreprises
- Argon2 pour les mots de passe
- Helmet / rate limiting
- sessions persistées
- idempotence paiements
- webhooks signés
- audit
- IA serveur
- adaptateurs paiement/notifications
- variables secrètes hors du code

## À configurer avant ouverture au public
1. Serveur cloud/VPS avec domaine HTTPS.
2. PostgreSQL managé ou sauvegardé.
3. OPENAI_API_KEY dans le secret manager.
4. Compte marchand auprès d'un prestataire de paiement disponible au Gabon.
5. URL webhook HTTPS du prestataire.
6. Fournisseur WhatsApp Business/SMS/e-mail.
7. Politique de confidentialité, CGU et consentements.
8. Sauvegardes et monitoring.
9. Tests de charge et sécurité.
10. Publication Android après validation.

Aucune donnée bancaire ou clé secrète ne doit être écrite dans le dépôt Git.
