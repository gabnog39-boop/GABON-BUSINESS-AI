# GABON BUSINESS AI — V8

V8 establishes the API and authorization boundary.

## Added
- Central tenant authorization policy.
- Write-role policy.
- Platform-owner policy.
- Canonical API contract for authentication, businesses, customers, products, AI, payments and owner console.

## Security rules
- Every business endpoint must verify the authenticated user's business membership.
- A business ID supplied by a client is never trusted by itself.
- Owner actions require the platform OWNER role.
- Paid business actions must additionally pass the V7 server-side subscription policy.
- Sensitive AI actions require explicit confirmation.
- Payment webhooks must be authenticated and idempotent.

## Not falsely marked complete
The contract is defined, but a production identity provider/session implementation and a real payment provider still need integration and end-to-end tests.
