# V6 ACCEPTANCE GATES

- [ ] Register/login/logout tested
- [ ] Business creation tested
- [ ] Role permissions tested
- [ ] Tenant isolation tested
- [ ] Subscription inactive => paid API blocked
- [ ] Subscription active => paid API allowed
- [ ] Expired subscription => blocked without data deletion
- [ ] Payment webhook idempotency tested
- [ ] Owner approval/rejection tested
- [ ] Customer CRUD tested
- [ ] Product/stock CRUD tested
- [ ] Quote -> order -> invoice -> payment tested
- [ ] Expense/accounting reports tested
- [ ] AI cannot execute sensitive actions without confirmation
- [ ] Audit log records sensitive actions
- [ ] No GABON 360 references/dependencies detected
- [ ] Android build/release candidate tested
