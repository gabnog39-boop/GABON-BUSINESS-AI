# GABON BUSINESS AI — V6 ROADMAP

## Goal
Pass from the V5 master/cadrage base to an auditable production implementation.

## Mandatory order
1. PostgreSQL schema + migrations
2. Authentication and tenant isolation
3. Owner console
4. Subscription lifecycle and payment webhooks
5. Customers/products/stock
6. Sales/quotes/invoices/payments
7. Expenses/suppliers/deliveries
8. AI assistant and business memory
9. Reports and document generation
10. Android + Web integration
11. Security audit
12. Acceptance tests
13. APK release candidate

## Non-negotiable rules
- Every business account requires an active paid subscription for paid features.
- Subscription state is authoritative on the server.
- Reinstallation must never bypass payment.
- Owner/master controls plans, access, versions and subscription validation.
- Strict tenant isolation: one company cannot read another company's data.
- No GABON 360 AI modules, terminology, dependencies or territorial features.
- API keys remain server-side; never embed secrets in the APK.
