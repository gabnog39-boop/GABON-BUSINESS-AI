# GABON BUSINESS AI — V10

V10 replaces the V9 development auth-header adapter with server-side sessions.

## Added
- Password hashing with Node.js `scrypt`.
- Random opaque session tokens.
- SHA-256 token hashes stored server-side.
- Login/register/logout/me.
- Session expiry.
- Business creation and membership.
- Authenticated business lookup.
- Authenticated customer read/create.
- Owner subscription listing.

## Production gates still required
- HTTPS/reverse proxy and secure deployment.
- CSRF strategy if cookie sessions are introduced; current API uses bearer tokens.
- Rate limiting and login abuse controls.
- Email verification/password reset.
- Payment provider signature verification and actual activation transaction.
- Full CRUD for products/invoices/payments/expenses.
- End-to-end tests.
- Android client integration.

No GABON 360 AI functionality is included.
