# GABON BUSINESS AI — FINAL CANDIDATE V39.2

Plateforme SaaS de gestion d'entreprise avec IA.

## Périmètre strict
Gestion d'entreprises, clients, produits/stock, ventes/factures, finance,
fournisseurs, abonnements, notifications, rapports et assistant IA.

**Aucun module GABON 360 AI, territorial, SIG, satellite, drone, parc,
forêt, biodiversité ou surveillance territoriale n'est inclus.**

## Architecture
- `backend/` — API canonique Node.js/Express + PostgreSQL
- `android/` — application Android
- `docs/` — documentation et critères de mise en production
- `tests/` — tests/acceptance

## État
Le projet est un **candidat final de développement**, pas une release
de production tant que PostgreSQL, HTTPS, paiement réel, URL API Android,
IA côté serveur et build signé n'ont pas été vérifiés en environnement réel.

## Monétisation
L'accès métier est soumis à un abonnement actif vérifié côté serveur.
L'installation ou la réinstallation de l'APK ne contourne pas cette règle.
