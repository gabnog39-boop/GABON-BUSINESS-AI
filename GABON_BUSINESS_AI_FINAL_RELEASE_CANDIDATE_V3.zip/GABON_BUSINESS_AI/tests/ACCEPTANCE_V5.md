# Tests d'acceptation V5

1. Créer un compte -> compte non actif tant qu'aucun abonnement n'est validé.
2. Consulter les offres -> accessible sans abonnement.
3. Soumettre une demande d'abonnement -> statut pending.
4. Tant que l'abonnement est pending/expired -> clients, stock, ventes, finance et IA sont refusés par le serveur.
5. Après activation serveur -> routes métier accessibles.
6. Après échéance -> routes métier bloquées, données conservées.
7. Une entreprise A ne peut pas lire les données de B.
8. Un paiement de facture avec la même clé d'idempotence ne crée pas deux paiements.
9. Les mots de passe ne sont pas stockés en clair ni en SHA-256.
10. Aucun terme/module GABON 360 n'est présent dans le code métier V5.
