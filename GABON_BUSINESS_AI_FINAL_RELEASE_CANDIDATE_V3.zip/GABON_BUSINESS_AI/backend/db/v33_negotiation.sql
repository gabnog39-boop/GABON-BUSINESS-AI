CREATE TABLE IF NOT EXISTS negotiation_sessions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  business_id UUID NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
  customer_id UUID REFERENCES customers(id) ON DELETE SET NULL,
  objective TEXT NOT NULL,
  target_price NUMERIC(18,2),
  minimum_price NUMERIC(18,2),
  proposed_price NUMERIC(18,2),
  currency TEXT NOT NULL DEFAULT 'XAF',
  strategy TEXT,
  objections JSONB NOT NULL DEFAULT '[]'::jsonb,
  recommendations JSONB NOT NULL DEFAULT '[]'::jsonb,
  status TEXT NOT NULL DEFAULT 'DRAFT',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_negotiation_scope
ON negotiation_sessions(business_id, customer_id, status);
