CREATE TABLE IF NOT EXISTS generated_documents (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  business_id UUID NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
  document_type TEXT NOT NULL,
  title TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'DRAFT',
  template_key TEXT,
  source_data JSONB NOT NULL DEFAULT '{}'::jsonb,
  rendered_content TEXT,
  total_xaf NUMERIC(14,2),
  created_by UUID,
  approved_by UUID,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  approved_at TIMESTAMPTZ
);

CREATE INDEX IF NOT EXISTS idx_generated_documents_business
  ON generated_documents(business_id);

CREATE INDEX IF NOT EXISTS idx_generated_documents_status
  ON generated_documents(status);
