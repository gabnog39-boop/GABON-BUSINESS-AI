CREATE TABLE IF NOT EXISTS voice_commands (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  business_id UUID NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
  user_id UUID,
  transcript TEXT NOT NULL,
  intent TEXT,
  parameters JSONB NOT NULL DEFAULT '{}'::jsonb,
  sensitivity TEXT NOT NULL DEFAULT 'READ_ONLY',
  status TEXT NOT NULL DEFAULT 'RECEIVED',
  confirmation_token TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  confirmed_at TIMESTAMPTZ
);

CREATE INDEX IF NOT EXISTS idx_voice_commands_business
  ON voice_commands(business_id, created_at DESC);
