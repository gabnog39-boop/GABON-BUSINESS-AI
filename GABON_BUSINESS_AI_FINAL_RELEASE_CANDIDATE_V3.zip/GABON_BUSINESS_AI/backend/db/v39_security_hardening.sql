-- V39 security hardening
-- No client can promote itself to platform owner.
-- The platform owner is selected out-of-band with PLATFORM_OWNER_USER_ID.
-- Do not store provider secrets in Android or in the database.
CREATE INDEX IF NOT EXISTS business_members_user_idx ON business_members(user_id);
CREATE INDEX IF NOT EXISTS subscriptions_business_status_idx ON subscriptions(business_id,status);
