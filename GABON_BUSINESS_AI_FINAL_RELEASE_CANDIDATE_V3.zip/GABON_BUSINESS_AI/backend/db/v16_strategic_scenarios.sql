-- GABON BUSINESS AI V16
-- Strategic "What-if?" simulator

CREATE TABLE IF NOT EXISTS strategic_scenarios (
  id BIGSERIAL PRIMARY KEY,
  business_id BIGINT NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  assumptions JSONB NOT NULL DEFAULT '{}'::jsonb,
  baseline JSONB NOT NULL DEFAULT '{}'::jsonb,
  projection JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_strategic_scenarios_business
  ON strategic_scenarios(business_id, created_at DESC);
