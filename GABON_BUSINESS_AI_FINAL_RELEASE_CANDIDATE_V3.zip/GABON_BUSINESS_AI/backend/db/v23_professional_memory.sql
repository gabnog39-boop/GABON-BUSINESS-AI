CREATE TABLE IF NOT EXISTS professional_memory (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  business_id UUID NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
  memory_type TEXT NOT NULL,
  memory_key TEXT NOT NULL,
  memory_value JSONB NOT NULL,
  confidence NUMERIC(5,4) DEFAULT 1.0,
  source TEXT NOT NULL DEFAULT 'USER',
  active BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (business_id, memory_key)
);

CREATE INDEX IF NOT EXISTS idx_professional_memory_business
  ON professional_memory(business_id, active);

CREATE INDEX IF NOT EXISTS idx_professional_memory_type
  ON professional_memory(business_id, memory_type);
