-- GABON BUSINESS AI V13
-- Dashboard, reports and AI business memory

CREATE TABLE IF NOT EXISTS business_goals (
  id BIGSERIAL PRIMARY KEY,
  business_id BIGINT NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  metric TEXT NOT NULL,
  target_value NUMERIC(18,2) NOT NULL,
  current_value NUMERIC(18,2) NOT NULL DEFAULT 0,
  period_start DATE NOT NULL,
  period_end DATE NOT NULL,
  status TEXT NOT NULL DEFAULT 'ACTIVE'
    CHECK (status IN ('ACTIVE','ACHIEVED','PAUSED','CANCELLED')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS business_reports (
  id BIGSERIAL PRIMARY KEY,
  business_id BIGINT NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
  report_type TEXT NOT NULL,
  period_start DATE NOT NULL,
  period_end DATE NOT NULL,
  payload JSONB NOT NULL,
  generated_by TEXT NOT NULL DEFAULT 'system',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS ai_business_memory (
  id BIGSERIAL PRIMARY KEY,
  business_id BIGINT NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
  memory_type TEXT NOT NULL,
  memory_key TEXT NOT NULL,
  memory_value JSONB NOT NULL,
  importance INTEGER NOT NULL DEFAULT 50 CHECK (importance BETWEEN 0 AND 100),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE (business_id, memory_type, memory_key)
);

CREATE INDEX IF NOT EXISTS idx_business_goals_business
  ON business_goals(business_id, status);

CREATE INDEX IF NOT EXISTS idx_business_reports_business_period
  ON business_reports(business_id, period_start, period_end);

CREATE INDEX IF NOT EXISTS idx_ai_business_memory_business
  ON ai_business_memory(business_id, importance DESC);
