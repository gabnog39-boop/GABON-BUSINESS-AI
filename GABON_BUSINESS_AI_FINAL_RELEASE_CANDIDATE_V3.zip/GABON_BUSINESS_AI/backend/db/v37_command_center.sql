CREATE TABLE IF NOT EXISTS command_center_snapshots (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  business_id UUID NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
  site_id UUID REFERENCES business_sites(id) ON DELETE SET NULL,
  health_score NUMERIC(6,2),
  revenue NUMERIC(18,2) NOT NULL DEFAULT 0,
  cash_received NUMERIC(18,2) NOT NULL DEFAULT 0,
  receivables NUMERIC(18,2) NOT NULL DEFAULT 0,
  expenses NUMERIC(18,2) NOT NULL DEFAULT 0,
  stock_alerts INTEGER NOT NULL DEFAULT 0,
  open_anomalies INTEGER NOT NULL DEFAULT 0,
  open_opportunities INTEGER NOT NULL DEFAULT 0,
  unread_notifications INTEGER NOT NULL DEFAULT 0,
  priorities JSONB NOT NULL DEFAULT '[]'::jsonb,
  recommendations JSONB NOT NULL DEFAULT '[]'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_command_center_scope
ON command_center_snapshots(business_id, site_id, created_at DESC);
