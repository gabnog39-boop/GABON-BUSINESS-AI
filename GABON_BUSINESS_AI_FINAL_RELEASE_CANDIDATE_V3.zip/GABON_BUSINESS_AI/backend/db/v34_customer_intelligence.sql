CREATE TABLE IF NOT EXISTS customer_intelligence_scores (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  business_id UUID NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
  customer_id UUID NOT NULL REFERENCES customers(id) ON DELETE CASCADE,
  loyalty_score NUMERIC(6,2) NOT NULL,
  value_score NUMERIC(6,2) NOT NULL,
  churn_risk_score NUMERIC(6,2) NOT NULL,
  purchase_frequency_score NUMERIC(6,2) NOT NULL,
  recency_score NUMERIC(6,2) NOT NULL,
  segment TEXT NOT NULL,
  explanation JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (business_id, customer_id)
);

CREATE INDEX IF NOT EXISTS idx_customer_intelligence_scope
ON customer_intelligence_scores(business_id, segment, churn_risk_score DESC);
