
CREATE TABLE IF NOT EXISTS suppliers (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  business_id UUID NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  phone TEXT,
  email TEXT,
  notes TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS purchase_orders (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  business_id UUID NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
  supplier_id UUID REFERENCES suppliers(id),
  number TEXT NOT NULL,
  status TEXT NOT NULL CHECK (status IN ('DRAFT','ORDERED','RECEIVED','CANCELLED')),
  total_xaf BIGINT NOT NULL DEFAULT 0 CHECK (total_xaf >= 0),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (business_id, number)
);

CREATE TABLE IF NOT EXISTS purchase_order_items (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  purchase_order_id UUID NOT NULL REFERENCES purchase_orders(id) ON DELETE CASCADE,
  product_id UUID NOT NULL REFERENCES products(id),
  quantity NUMERIC(18,3) NOT NULL CHECK (quantity > 0),
  unit_cost_xaf BIGINT NOT NULL CHECK (unit_cost_xaf >= 0),
  line_total_xaf BIGINT NOT NULL CHECK (line_total_xaf >= 0)
);

CREATE TABLE IF NOT EXISTS expense_categories (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  business_id UUID NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  UNIQUE (business_id, name)
);

CREATE INDEX IF NOT EXISTS suppliers_business_idx ON suppliers(business_id);
CREATE INDEX IF NOT EXISTS purchase_orders_business_idx ON purchase_orders(business_id);
CREATE INDEX IF NOT EXISTS expenses_business_date_idx ON expenses(business_id, occurred_at DESC);
