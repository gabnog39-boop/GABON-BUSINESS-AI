-- GABON BUSINESS AI V19
-- AI stock and purchasing director foundation

CREATE TABLE IF NOT EXISTS stock_ai_recommendations (
  id BIGSERIAL PRIMARY KEY,
  business_id BIGINT NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
  product_id BIGINT NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  recommendation_type TEXT NOT NULL,
  priority TEXT NOT NULL DEFAULT 'MEDIUM'
    CHECK (priority IN ('LOW','MEDIUM','HIGH','URGENT')),
  suggested_quantity NUMERIC(18,2) NOT NULL DEFAULT 0,
  reason TEXT NOT NULL,
  payload JSONB NOT NULL DEFAULT '{}'::jsonb,
  status TEXT NOT NULL DEFAULT 'PROPOSED'
    CHECK (status IN ('PROPOSED','CONFIRMED','DONE','REJECTED')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_stock_ai_recommendations_business
  ON stock_ai_recommendations(business_id, status, created_at DESC);
