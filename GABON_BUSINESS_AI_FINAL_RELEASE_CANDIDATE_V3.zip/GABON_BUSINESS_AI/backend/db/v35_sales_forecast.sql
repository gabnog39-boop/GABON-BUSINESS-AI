CREATE TABLE IF NOT EXISTS sales_forecasts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  business_id UUID NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
  site_id UUID REFERENCES business_sites(id) ON DELETE SET NULL,
  forecast_start DATE NOT NULL,
  forecast_end DATE NOT NULL,
  baseline_revenue NUMERIC(18,2) NOT NULL DEFAULT 0,
  projected_revenue NUMERIC(18,2) NOT NULL DEFAULT 0,
  projected_sales_count NUMERIC(18,2) NOT NULL DEFAULT 0,
  confidence_pct NUMERIC(5,2),
  scenario TEXT NOT NULL DEFAULT 'CENTRAL',
  assumptions JSONB NOT NULL DEFAULT '{}'::jsonb,
  risks JSONB NOT NULL DEFAULT '[]'::jsonb,
  recommendations JSONB NOT NULL DEFAULT '[]'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_sales_forecasts_scope
ON sales_forecasts(business_id, site_id, forecast_start, forecast_end);
