CREATE TABLE IF NOT EXISTS director_ai_sessions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  business_id UUID NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
  user_id UUID,
  user_message TEXT NOT NULL,
  specialist TEXT NOT NULL DEFAULT 'GENERAL',
  plan JSONB NOT NULL DEFAULT '{}'::jsonb,
  result JSONB NOT NULL DEFAULT '{}'::jsonb,
  status TEXT NOT NULL DEFAULT 'READY',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_director_ai_business
ON director_ai_sessions(business_id, created_at DESC);
