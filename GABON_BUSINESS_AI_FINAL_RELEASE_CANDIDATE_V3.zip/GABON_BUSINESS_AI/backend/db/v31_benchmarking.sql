CREATE TABLE IF NOT EXISTS benchmark_snapshots (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  business_id UUID NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
  site_id UUID REFERENCES business_sites(id) ON DELETE SET NULL,
  period_start DATE NOT NULL,
  period_end DATE NOT NULL,
  revenue NUMERIC(18,2) NOT NULL DEFAULT 0,
  expenses NUMERIC(18,2) NOT NULL DEFAULT 0,
  gross_margin_pct NUMERIC(8,2),
  receivables NUMERIC(18,2) NOT NULL DEFAULT 0,
  stock_alerts INTEGER NOT NULL DEFAULT 0,
  sales_count INTEGER NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_benchmark_scope
ON benchmark_snapshots(business_id, site_id, period_start, period_end);
