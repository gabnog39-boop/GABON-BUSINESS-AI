
const { pool } = require("./db");

async function createSupplier({businessId,name,phone,email,notes}) {
  const q = await pool.query(
    `INSERT INTO suppliers(business_id,name,phone,email,notes)
     VALUES($1,$2,$3,$4,$5)
     RETURNING id,name,phone,email,notes,created_at`,
    [businessId,name.trim(),phone||null,email||null,notes||null]
  );
  return q.rows[0];
}

async function createExpense({businessId,label,amountXaf,category,occurredAt}) {
  const amount = Number(amountXaf);
  if (!label || !Number.isFinite(amount) || amount < 0)
    throw Object.assign(new Error("INVALID_EXPENSE"),{statusCode:400});
  const q = await pool.query(
    `INSERT INTO expenses(business_id,label,amount_xaf,category,occurred_at)
     VALUES($1,$2,$3,$4,COALESCE($5::timestamptz,now()))
     RETURNING id,label,amount_xaf,category,occurred_at`,
    [businessId,label.trim(),Math.round(amount),category||null,occurredAt||null]
  );
  return q.rows[0];
}

async function createPurchase({businessId,supplierId,number,items}) {
  if (!Array.isArray(items) || !items.length)
    throw Object.assign(new Error("PURCHASE_ITEMS_REQUIRED"),{statusCode:400});

  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    const ids = items.map(x=>x.product_id);
    const products = await client.query(
      `SELECT id FROM products WHERE business_id=$1 AND id=ANY($2::uuid[]) AND active=true FOR UPDATE`,
      [businessId,ids]
    );
    const valid = new Set(products.rows.map(x=>x.id));
    let total = 0;

    for (const x of items) {
      const qty=Number(x.quantity), cost=Number(x.unit_cost_xaf);
      if (!valid.has(x.product_id)) throw Object.assign(new Error("PRODUCT_NOT_FOUND"),{statusCode:404});
      if (!Number.isFinite(qty)||qty<=0||!Number.isFinite(cost)||cost<0)
        throw Object.assign(new Error("INVALID_PURCHASE_ITEM"),{statusCode:400});
      total += Math.round(qty*cost);
    }

    const po=await client.query(
      `INSERT INTO purchase_orders(business_id,supplier_id,number,status,total_xaf)
       VALUES($1,$2,$3,'RECEIVED',$4)
       RETURNING id,number,status,total_xaf,created_at`,
      [businessId,supplierId||null,number,total]
    );

    for(const x of items){
      await client.query(
        `INSERT INTO purchase_order_items(purchase_order_id,product_id,quantity,unit_cost_xaf,line_total_xaf)
         VALUES($1,$2,$3,$4,$5)`,
        [po.rows[0].id,x.product_id,x.quantity,x.unit_cost_xaf,Math.round(Number(x.quantity)*Number(x.unit_cost_xaf))]
      );
      await client.query(
        `UPDATE products SET stock_qty=stock_qty+$1 WHERE id=$2 AND business_id=$3`,
        [x.quantity,x.product_id,businessId]
      );
      await client.query(
        `INSERT INTO stock_movements(business_id,product_id,type,quantity,reference)
         VALUES($1,$2,'IN',$3,$4)`,
        [businessId,x.product_id,x.quantity,`PURCHASE:${po.rows[0].id}`]
      );
    }
    await client.query("COMMIT");
    return po.rows[0];
  } catch(e){ await client.query("ROLLBACK"); throw e; }
  finally{ client.release(); }
}

async function financialSummary(businessId) {
  const q=await pool.query(`
    SELECT
      COALESCE((SELECT SUM(total_xaf) FROM invoices
        WHERE business_id=$1 AND status <> 'CANCELLED'),0)::bigint AS invoiced_xaf,
      COALESCE((SELECT SUM(amount_xaf) FROM payments
        WHERE business_id=$1),0)::bigint AS received_xaf,
      COALESCE((SELECT SUM(amount_xaf) FROM expenses
        WHERE business_id=$1),0)::bigint AS expenses_xaf,
      COALESCE((SELECT SUM(total_xaf) FROM purchase_orders
        WHERE business_id=$1 AND status <> 'CANCELLED'),0)::bigint AS purchases_xaf
  `,[businessId]);
  const r=q.rows[0];
  return {
    invoiced_xaf:Number(r.invoiced_xaf),
    received_xaf:Number(r.received_xaf),
    expenses_xaf:Number(r.expenses_xaf),
    purchases_xaf:Number(r.purchases_xaf),
    estimated_margin_xaf:Number(r.received_xaf)-Number(r.expenses_xaf)-Number(r.purchases_xaf),
    receivables_xaf:Number(r.invoiced_xaf)-Number(r.received_xaf)
  };
}

module.exports={createSupplier,createExpense,createPurchase,financialSummary};
