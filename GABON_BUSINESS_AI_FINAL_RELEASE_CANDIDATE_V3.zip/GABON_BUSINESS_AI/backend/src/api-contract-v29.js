export const V29_NOTIFICATION_ROUTES = {
  list: 'GET /api/notifications',
  unreadCount: 'GET /api/notifications/unread-count',
  markRead: 'POST /api/notifications/:notificationId/read',
  preferences: 'GET /api/notifications/preferences',
  updatePreferences: 'PUT /api/notifications/preferences',
  dispatch: 'POST /api/notifications/dispatch'
};
