// V16 — Strategic "What-if?" simulator.
// This is a decision-support model, not a guarantee or financial forecast.

function makeStrategicSimulator(v13Service, pool) {
  function num(v) {
    const n = Number(v);
    return Number.isFinite(n) ? n : 0;
  }

  function simulate(baseline, assumptions) {
    const revenue = num(baseline.revenue);
    const expenses = num(baseline.expenses);
    const receivables = num(baseline.receivables);

    const revenueChangePct = num(assumptions.revenueChangePct);
    const priceChangePct = num(assumptions.priceChangePct);
    const volumeChangePct = num(assumptions.volumeChangePct);
    const expenseChangePct = num(assumptions.expenseChangePct);
    const newFixedCosts = num(assumptions.newFixedCosts);

    // Price and volume effects are modeled independently for transparency.
    const projectedRevenue =
      revenue *
      (1 + priceChangePct / 100) *
      (1 + volumeChangePct / 100) *
      (1 + revenueChangePct / 100);

    const projectedExpenses =
      expenses * (1 + expenseChangePct / 100) + newFixedCosts;

    const projectedResult = projectedRevenue - projectedExpenses;
    const margin = projectedRevenue > 0
      ? (projectedResult / projectedRevenue) * 100
      : 0;

    return {
      baseline: { revenue, expenses, receivables },
      projection: {
        revenue: projectedRevenue,
        expenses: projectedExpenses,
        operatingResult: projectedResult,
        marginPct: margin
      },
      deltas: {
        revenue: projectedRevenue - revenue,
        expenses: projectedExpenses - expenses,
        operatingResult: projectedResult - (revenue - expenses)
      },
      assumptions: {
        revenueChangePct,
        priceChangePct,
        volumeChangePct,
        expenseChangePct,
        newFixedCosts
      }
    };
  }

  async function createScenario(businessId, name, assumptions) {
    const dashboard = await v13Service.dashboard(businessId);
    const baseline = {
      revenue: dashboard.paid,
      expenses: dashboard.expenses + dashboard.purchases,
      receivables: dashboard.receivables
    };
    const projection = simulate(baseline, assumptions);

    const q = await pool.query(`
      INSERT INTO strategic_scenarios
        (business_id,name,assumptions,baseline,projection)
      VALUES ($1,$2,$3,$4,$5)
      RETURNING *
    `, [businessId, name, assumptions || {}, baseline, projection]);

    return q.rows[0];
  }

  async function listScenarios(businessId) {
    const q = await pool.query(`
      SELECT id,name,assumptions,baseline,projection,created_at
      FROM strategic_scenarios
      WHERE business_id=$1
      ORDER BY created_at DESC
      LIMIT 100
    `, [businessId]);
    return q.rows;
  }

  return { simulate, createScenario, listScenarios };
}

module.exports = { makeStrategicSimulator };
