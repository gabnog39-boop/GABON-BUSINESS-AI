export const V36_ANOMALY_ROUTES = {
  detect: 'POST /api/anomalies/detect',
  list: 'GET /api/anomalies',
  detail: 'GET /api/anomalies/:anomalyId',
  review: 'POST /api/anomalies/:anomalyId/review'
};
