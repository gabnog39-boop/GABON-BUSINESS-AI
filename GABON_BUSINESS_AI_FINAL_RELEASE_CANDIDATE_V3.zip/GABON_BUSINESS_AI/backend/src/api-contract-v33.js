export const V33_NEGOTIATION_ROUTES = {
  prepare: 'POST /api/negotiations',
  list: 'GET /api/negotiations',
  detail: 'GET /api/negotiations/:negotiationId',
  plan: 'POST /api/negotiations/:negotiationId/plan',
  approve: 'POST /api/negotiations/:negotiationId/approve'
};
