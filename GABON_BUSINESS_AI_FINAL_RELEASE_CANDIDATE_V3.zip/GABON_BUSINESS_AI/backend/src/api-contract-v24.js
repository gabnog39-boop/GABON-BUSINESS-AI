export const V24_VOICE_ROUTES = {
  transcribe: 'POST /api/voice/transcribe',
  interpret: 'POST /api/voice/interpret',
  prepare: 'POST /api/voice/command',
  confirm: 'POST /api/voice/command/:commandId/confirm',
  reject: 'POST /api/voice/command/:commandId/reject',
  history: 'GET /api/voice/commands'
};
