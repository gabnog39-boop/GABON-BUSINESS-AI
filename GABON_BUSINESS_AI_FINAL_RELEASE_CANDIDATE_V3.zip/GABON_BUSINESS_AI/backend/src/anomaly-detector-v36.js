const TYPES = new Set([
  'SALES_DROP',
  'SALES_SPIKE',
  'EXPENSE_SPIKE',
  'PAYMENT_ANOMALY',
  'RECEIVABLES_SPIKE',
  'STOCK_ANOMALY',
  'ACTIVITY_ANOMALY'
]);

const SEVERITIES = new Set(['LOW', 'MEDIUM', 'HIGH', 'CRITICAL']);

function n(value) {
  const x = Number(value);
  return Number.isFinite(x) ? x : 0;
}

function pctChange(current, baseline) {
  if (!baseline) return current ? 100 : 0;
  return ((current - baseline) / Math.abs(baseline)) * 100;
}

function severityFromScore(score) {
  if (score >= 90) return 'CRITICAL';
  if (score >= 70) return 'HIGH';
  if (score >= 45) return 'MEDIUM';
  return 'LOW';
}

export function detectAnomalies(input = {}) {
  if (!input.businessId) throw new Error('businessId obligatoire');

  const currentSales = n(input.currentSales);
  const baselineSales = n(input.baselineSales);
  const currentExpenses = n(input.currentExpenses);
  const baselineExpenses = n(input.baselineExpenses);
  const currentReceivables = n(input.currentReceivables);
  const baselineReceivables = n(input.baselineReceivables);
  const currentStock = n(input.currentStock);
  const baselineStock = n(input.baselineStock);

  const changes = {
    sales: pctChange(currentSales, baselineSales),
    expenses: pctChange(currentExpenses, baselineExpenses),
    receivables: pctChange(currentReceivables, baselineReceivables),
    stock: pctChange(currentStock, baselineStock)
  };

  const anomalies = [];

  if (changes.sales <= -30) {
    anomalies.push(make('SALES_DROP', changes.sales, input, {
      title: 'Baisse inhabituelle des ventes',
      explanation: `Les ventes sont en baisse de ${Math.abs(changes.sales).toFixed(1)}% par rapport à la référence.`,
      evidence: { currentSales, baselineSales, changePct: changes.sales }
    }));
  }

  if (changes.sales >= 50) {
    anomalies.push(make('SALES_SPIKE', changes.sales, input, {
      title: 'Hausse inhabituelle des ventes',
      explanation: `Les ventes sont en hausse de ${changes.sales.toFixed(1)}% par rapport à la référence.`,
      evidence: { currentSales, baselineSales, changePct: changes.sales }
    }));
  }

  if (changes.expenses >= 30) {
    anomalies.push(make('EXPENSE_SPIKE', changes.expenses, input, {
      title: 'Hausse inhabituelle des dépenses',
      explanation: `Les dépenses sont en hausse de ${changes.expenses.toFixed(1)}% par rapport à la référence.`,
      evidence: { currentExpenses, baselineExpenses, changePct: changes.expenses }
    }));
  }

  if (changes.receivables >= 40) {
    anomalies.push(make('RECEIVABLES_SPIKE', changes.receivables, input, {
      title: 'Hausse inhabituelle des créances',
      explanation: `Les créances sont en hausse de ${changes.receivables.toFixed(1)}%.`,
      evidence: { currentReceivables, baselineReceivables, changePct: changes.receivables }
    }));
  }

  if (baselineStock && changes.stock <= -40) {
    anomalies.push(make('STOCK_ANOMALY', Math.abs(changes.stock), input, {
      title: 'Variation importante du stock',
      explanation: `Le stock a diminué de ${Math.abs(changes.stock).toFixed(1)}% par rapport à la référence.`,
      evidence: { currentStock, baselineStock, changePct: changes.stock }
    }));
  }

  return anomalies;
}

function make(type, rawScore, input, details) {
  const score = Math.max(0, Math.min(100, Math.abs(Number(rawScore))));
  const severity = severityFromScore(score);

  return {
    businessId: input.businessId,
    siteId: input.siteId || null,
    anomalyType: type,
    severity,
    score: Number(score.toFixed(2)),
    title: details.title,
    explanation: details.explanation,
    evidence: details.evidence,
    status: 'OPEN'
  };
}

export function assertAnomalyScope(context, businessId, siteId = null) {
  if (!context?.allowedBusinessIds?.includes(businessId)) {
    throw new Error('Entreprise non autorisée');
  }
  if (siteId && context.allowedSiteIds && !context.allowedSiteIds.includes(siteId)) {
    throw new Error('Site non autorisé');
  }
  return true;
}

export function reviewAnomaly(anomaly, decision) {
  if (!anomaly || anomaly.status !== 'OPEN') {
    throw new Error('Anomalie non ouverte');
  }
  const normalized = String(decision || '').toUpperCase();
  if (!['CONFIRMED', 'DISMISSED', 'INVESTIGATE'].includes(normalized)) {
    throw new Error('Décision de revue invalide');
  }
  return {
    ...anomaly,
    status: normalized,
    reviewedAt: new Date().toISOString()
  };
}
