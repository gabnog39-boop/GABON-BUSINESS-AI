/**
 * GABON BUSINESS AI — canonical API
 * Business management only. No territorial/GABON 360 functionality.
 */
const express = require("express");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
const { pool } = require("./db");
const { SERVICE_FILES, loadOptionalServices } = require("./canonical-registry-v39");
const { hashPassword, verifyPassword, createSession, getSession, revokeSession } = require("./auth-service-v10");

const app = express();
app.use(helmet());
app.use(express.json({ limit: "2mb" }));
app.use(rateLimit({ windowMs: 60_000, limit: 120, standardHeaders: true, legacyHeaders: false }));

const services = loadOptionalServices(__dirname);
const cleanEmail = v => String(v || "").trim().toLowerCase();
const bearer = req => String(req.headers.authorization || "").replace(/^Bearer\s+/i, "").trim();

async function auth(req, res, next) {
  try {
    const session = await getSession(bearer(req));
    if (!session) return res.status(401).json({ error: "UNAUTHENTICATED" });
    req.user = session;
    next();
  } catch (e) { next(e); }
}

async function businessAccess(req, res, next) {
  try {
    const id = req.params.businessId || req.headers["x-business-id"];
    if (!id) return res.status(400).json({ error: "BUSINESS_ID_REQUIRED" });
    const q = await pool.query(
      `SELECT b.id,b.name,b.sector,b.currency,b.owner_user_id,bm.role
       FROM businesses b JOIN business_members bm ON bm.business_id=b.id
       WHERE b.id=$1 AND bm.user_id=$2`, [id, req.user.user_id]);
    if (!q.rows[0]) return res.status(403).json({ error: "BUSINESS_ACCESS_DENIED" });
    req.business = q.rows[0];
    next();
  } catch (e) { next(e); }
}

async function paidAccess(req, res, next) {
  try {
    const q = await pool.query(`SELECT s.id,s.status,s.starts_at,s.expires_at,p.code,p.name,p.price_xaf
      FROM subscriptions s JOIN plans p ON p.id=s.plan_id
      WHERE s.business_id=$1 AND s.status='ACTIVE' AND s.expires_at > now()
      ORDER BY s.expires_at DESC LIMIT 1`, [req.business.id]);
    if (!q.rows[0]) return res.status(402).json({ error: "SUBSCRIPTION_REQUIRED", message: "Paiement et activation de l'abonnement requis." });
    req.subscription = q.rows[0]; next();
  } catch(e){ next(e); }
}

app.get("/api/health", (_req,res) => res.json({ ok:true, service:"GABON BUSINESS AI", version:"39.1", entrypoint:"canonical" }));
app.get("/api/ready", async (_req,res) => {
  try { await pool.query("SELECT 1"); res.json({ok:true,ready:true, database:true, serviceRegistry:{total:SERVICE_FILES.length}}); }
  catch(e) { res.status(503).json({ok:false,ready:false,database:false,reason:"DATABASE_UNAVAILABLE"}); }
});
app.get("/api/system/services", (_req,res) => res.json({ project:"GABON BUSINESS AI", territorialModules:false, services:SERVICE_FILES.map(file=>({file,loaded:!(services[file.replace(/\.js$/,'')]?.available===false)})) }));

app.post("/api/auth/register", async (req,res,next)=>{
  try {
    const email=cleanEmail(req.body.email), password=String(req.body.password||""), businessName=String(req.body.businessName||"").trim();
    if(!/^\S+@\S+\.\S+$/.test(email) || password.length<10 || !businessName) return res.status(400).json({error:"INVALID_REGISTRATION"});
    const client=await pool.connect();
    try { await client.query("BEGIN");
      const u=await client.query("INSERT INTO platform_users(email,password_hash,role) VALUES($1,$2,'USER') RETURNING id,email,role",[email,hashPassword(password)]);
      const b=await client.query("INSERT INTO businesses(name,owner_user_id) VALUES($1,$2) RETURNING id,name,currency",[businessName,u.rows[0].id]);
      await client.query("INSERT INTO business_members(business_id,user_id,role) VALUES($1,$2,'OWNER')",[b.rows[0].id,u.rows[0].id]);
      const plan=await client.query("SELECT id FROM plans WHERE code='ESSENTIEL' AND active=true LIMIT 1");
      if(!plan.rows[0]) throw new Error('DEFAULT_PLAN_MISSING');
      await client.query("INSERT INTO subscriptions(business_id,plan_id,status) VALUES($1,$2,'PENDING')",[b.rows[0].id,plan.rows[0].id]);
      await client.query("COMMIT");
      const session=await createSession(u.rows[0].id);
      res.status(201).json({user:u.rows[0],business:b.rows[0],session});
    } catch(e){ await client.query("ROLLBACK"); if(e.code==='23505') return res.status(409).json({error:"EMAIL_ALREADY_EXISTS"}); throw e; }
    finally { client.release(); }
  } catch(e){next(e)}
});

app.post("/api/auth/login", async (req,res,next)=>{
  try {
    const email=cleanEmail(req.body.email), password=String(req.body.password||"");
    const q=await pool.query("SELECT id,email,password_hash,role,active FROM platform_users WHERE email=$1",[email]);
    const u=q.rows[0]; if(!u || !u.active || !verifyPassword(password,u.password_hash)) return res.status(401).json({error:"INVALID_CREDENTIALS"});
    const session=await createSession(u.id);
    res.json({user:{id:u.id,email:u.email,role:u.role},session});
  } catch(e){next(e)}
});
app.post("/api/auth/logout", auth, async (req,res,next)=>{ try{await revokeSession(bearer(req));res.status(204).end()}catch(e){next(e)} });
app.get("/api/auth/me", auth, async (req,res)=>res.json({user:{id:req.user.user_id,email:req.user.email,role:req.user.role}}));
app.get("/api/businesses", auth, async (req,res,next)=>{try{const q=await pool.query(`SELECT b.id,b.name,b.sector,b.currency,b.owner_user_id,bm.role FROM businesses b JOIN business_members bm ON bm.business_id=b.id WHERE bm.user_id=$1 ORDER BY b.created_at DESC`,[req.user.user_id]);res.json({businesses:q.rows})}catch(e){next(e)}});

app.get("/api/subscription/:businessId", auth, businessAccess, async (req,res,next)=>{try{
 const q=await pool.query(`SELECT s.id,s.status,s.starts_at,s.expires_at,p.code,p.name,p.price_xaf,p.duration_days
 FROM subscriptions s JOIN plans p ON p.id=s.plan_id WHERE s.business_id=$1 ORDER BY s.created_at DESC LIMIT 1`,[req.business.id]);
 res.json({subscription:q.rows[0]||null});
}catch(e){next(e)}});

async function ownerOnly(req,res,next){
  // Platform owner is deliberately separate from a business OWNER.
  // Configure PLATFORM_OWNER_USER_ID on the server; never expose this role to client code.
  const configured = String(process.env.PLATFORM_OWNER_USER_ID || '').trim();
  if(!configured || String(req.user.user_id) !== configured)
    return res.status(403).json({error:'PLATFORM_OWNER_ONLY'});
  next();
}
app.get("/api/owner/subscriptions", auth, ownerOnly, async (_req,res,next)=>{try{const q=await pool.query(`SELECT s.*,b.name business_name,p.code plan_code,p.name plan_name,p.price_xaf FROM subscriptions s JOIN businesses b ON b.id=s.business_id JOIN plans p ON p.id=s.plan_id ORDER BY s.created_at DESC`);res.json({subscriptions:q.rows})}catch(e){next(e)}});
app.post("/api/owner/subscriptions/:id/activate", auth, ownerOnly, async (req,res,next)=>{try{
 const days=Number(req.body.durationDays||30); if(!Number.isInteger(days)||days<1||days>3660)return res.status(400).json({error:'INVALID_DURATION'});
 const q=await pool.query(`UPDATE subscriptions SET status='ACTIVE',starts_at=now(),expires_at=now()+($2 || ' days')::interval WHERE id=$1 RETURNING *`,[req.params.id,days]);
 if(!q.rows[0])return res.status(404).json({error:'SUBSCRIPTION_NOT_FOUND'}); res.json({subscription:q.rows[0]});
}catch(e){next(e)}});

app.get("/api/dashboard/:businessId", auth, businessAccess, paidAccess, async (req,res,next)=>{try{
 const id=req.business.id;
 const q=await pool.query(`SELECT
 COALESCE((SELECT SUM(total_xaf) FROM invoices WHERE business_id=$1 AND status<>'CANCELLED'),0) invoiced_xaf,
 COALESCE((SELECT SUM(amount_xaf) FROM payments WHERE business_id=$1),0) paid_xaf,
 COALESCE((SELECT SUM(amount_xaf) FROM expenses WHERE business_id=$1),0) expenses_xaf,
 COALESCE((SELECT SUM(total_xaf) FROM invoices WHERE business_id=$1 AND status IN ('ISSUED','PARTIAL')),0) receivables_xaf,
 (SELECT COUNT(*) FROM products WHERE business_id=$1 AND active=true AND stock_qty<=low_stock_threshold) stock_alerts`,[id]);
 res.json({business:req.business,kpis:q.rows[0]});
}catch(e){next(e)}});

app.get("/api/customers/:businessId", auth, businessAccess, paidAccess, async (req,res,next)=>{try{const q=await pool.query("SELECT id,name,phone,email,notes,created_at FROM customers WHERE business_id=$1 ORDER BY created_at DESC",[req.business.id]);res.json({customers:q.rows})}catch(e){next(e)}});
app.post("/api/customers/:businessId", auth, businessAccess, paidAccess, async (req,res,next)=>{try{const name=String(req.body.name||'').trim();if(!name)return res.status(400).json({error:'NAME_REQUIRED'});const q=await pool.query("INSERT INTO customers(business_id,name,phone,email,notes) VALUES($1,$2,$3,$4,$5) RETURNING *",[req.business.id,name,req.body.phone||null,req.body.email||null,req.body.notes||null]);res.status(201).json(q.rows[0])}catch(e){next(e)}});
app.get("/api/products/:businessId", auth, businessAccess, paidAccess, async (req,res,next)=>{try{const q=await pool.query("SELECT id,name,sku,unit_price_xaf,stock_qty,low_stock_threshold,active FROM products WHERE business_id=$1 ORDER BY created_at DESC",[req.business.id]);res.json({products:q.rows})}catch(e){next(e)}});
app.post("/api/products/:businessId", auth, businessAccess, paidAccess, async (req,res,next)=>{try{const name=String(req.body.name||'').trim();if(!name)return res.status(400).json({error:'NAME_REQUIRED'});const q=await pool.query("INSERT INTO products(business_id,name,sku,unit_price_xaf,stock_qty,low_stock_threshold) VALUES($1,$2,$3,$4,$5,$6) RETURNING *",[req.business.id,name,req.body.sku||null,Number(req.body.unitPriceXaf||0),Number(req.body.stockQty||0),Number(req.body.lowStockThreshold||0)]);res.status(201).json(q.rows[0])}catch(e){next(e)}});

// Payment provider boundary: verifies that a real provider integration must call this endpoint.
// It intentionally does NOT trust a client-provided "paid=true" flag.
app.post("/api/payments/webhook", async (req,res,next)=>{
  try {
    const provider = String(req.body?.provider || '').trim();
    const reference = String(req.body?.reference || '').trim();
    const businessId = String(req.body?.businessId || '').trim();
    const status = String(req.body?.status || '').toUpperCase();
    if(!provider || !reference || !businessId || !['PAID','SUCCESS','COMPLETED'].includes(status))
      return res.status(400).json({error:'INVALID_PAYMENT_WEBHOOK'});
    // Provider signature verification and plan mapping must be implemented for the selected provider.
    // Until then, reject the event rather than granting access on unverified data.
    return res.status(501).json({error:'PAYMENT_PROVIDER_NOT_CONFIGURED'});
  } catch(e){ next(e); }
});

app.use((err,_req,res,_next)=>{console.error(err);res.status(500).json({error:"INTERNAL_SERVER_ERROR"})});
const port=Number(process.env.PORT||3000); if(require.main===module) app.listen(port,()=>console.log(`GABON BUSINESS AI canonical API on ${port}`));
module.exports=app;
