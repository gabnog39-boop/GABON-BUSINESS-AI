const PRIORITY_ORDER = {
  CRITICAL: 4,
  HIGH: 3,
  NORMAL: 2,
  LOW: 1
};

function num(v) {
  const n = Number(v);
  return Number.isFinite(n) ? n : 0;
}

export function buildCommandCenter(input = {}) {
  if (!input.businessId) throw new Error('businessId obligatoire');

  const health = num(input.healthScore);
  const anomalies = Array.isArray(input.anomalies) ? input.anomalies : [];
  const opportunities = Array.isArray(input.opportunities) ? input.opportunities : [];
  const notifications = Array.isArray(input.notifications) ? input.notifications : [];

  const priorities = [
    ...anomalies.map(a => ({
      source: 'ANOMALY',
      severity: String(a.severity || 'NORMAL').toUpperCase(),
      title: a.title || 'Anomalie à vérifier',
      explanation: a.explanation || ''
    })),
    ...notifications.map(n => ({
      source: 'NOTIFICATION',
      severity: String(n.priority || 'NORMAL').toUpperCase(),
      title: n.title || 'Notification',
      explanation: n.body || ''
    })),
    ...opportunities.map(o => ({
      source: 'OPPORTUNITY',
      severity: String(o.priority || 'NORMAL').toUpperCase(),
      title: o.title || 'Opportunité',
      explanation: o.description || ''
    }))
  ].sort((a, b) =>
    (PRIORITY_ORDER[b.severity] || 0) - (PRIORITY_ORDER[a.severity] || 0)
  );

  const recommendations = [];

  if (health < 50) {
    recommendations.push({
      priority: 'HIGH',
      action: 'Analyser les causes principales de la baisse de santé de l’entreprise.'
    });
  }

  if (num(input.receivables) > num(input.cashReceived) * 2 && num(input.cashReceived) > 0) {
    recommendations.push({
      priority: 'HIGH',
      action: 'Prioriser le recouvrement des créances importantes.'
    });
  }

  if (num(input.stockAlerts) > 0) {
    recommendations.push({
      priority: 'HIGH',
      action: 'Vérifier les produits sous seuil de stock.'
    });
  }

  if (opportunities.length > 0) {
    recommendations.push({
      priority: 'NORMAL',
      action: 'Examiner les opportunités commerciales proposées par l’IA.'
    });
  }

  return {
    businessId: input.businessId,
    siteId: input.siteId || null,
    healthScore: health,
    revenue: num(input.revenue),
    cashReceived: num(input.cashReceived),
    receivables: num(input.receivables),
    expenses: num(input.expenses),
    stockAlerts: Math.max(0, Math.floor(num(input.stockAlerts))),
    openAnomalies: anomalies.length,
    openOpportunities: opportunities.length,
    unreadNotifications: notifications.length,
    priorities: priorities.slice(0, 20),
    recommendations,
    generatedAt: new Date().toISOString()
  };
}

export function assertCommandCenterScope(context, businessId, siteId = null) {
  if (!context?.allowedBusinessIds?.includes(businessId)) {
    throw new Error('Entreprise non autorisée');
  }
  if (siteId && context.allowedSiteIds && !context.allowedSiteIds.includes(siteId)) {
    throw new Error('Site non autorisé');
  }
  return true;
}

export function buildExecutiveBrief(center) {
  return {
    healthScore: center.healthScore,
    headline:
      center.healthScore >= 80 ? 'Situation globalement saine' :
      center.healthScore >= 60 ? 'Situation à surveiller' :
      'Action prioritaire recommandée',
    topPriorities: center.priorities.slice(0, 5),
    recommendations: center.recommendations
  };
}
