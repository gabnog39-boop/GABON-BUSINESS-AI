const METRICS = [
  'revenue',
  'expenses',
  'grossMarginPct',
  'receivables',
  'stockAlerts',
  'salesCount'
];

export function normalizeBenchmark(input = {}) {
  const result = {};
  for (const metric of METRICS) {
    result[metric] = Number(input[metric] || 0);
  }
  return result;
}

export function calculateBenchmark(records = []) {
  if (!records.length) {
    return { records: [], averages: {}, rankings: [], insights: [] };
  }

  const normalized = records.map(r => ({
    id: r.id,
    businessId: r.businessId,
    siteId: r.siteId || null,
    name: r.name || r.id,
    metrics: normalizeBenchmark(r.metrics || r)
  }));

  const averages = {};
  for (const metric of METRICS) {
    averages[metric] =
      normalized.reduce((sum, r) => sum + r.metrics[metric], 0) /
      normalized.length;
  }

  const rankings = normalized.map(r => ({
    id: r.id,
    name: r.name,
    revenueRank: rankDescending(normalized, r, 'revenue'),
    marginRank: rankDescending(normalized, r, 'grossMarginPct'),
    salesRank: rankDescending(normalized, r, 'salesCount')
  }));

  const insights = normalized.map(r => ({
    id: r.id,
    name: r.name,
    revenueVsAveragePct: percentageDelta(r.metrics.revenue, averages.revenue),
    marginVsAveragePct: percentageDelta(r.metrics.grossMarginPct, averages.grossMarginPct),
    receivablesVsAveragePct: percentageDelta(r.metrics.receivables, averages.receivables),
    stockAlertsVsAveragePct: percentageDelta(r.metrics.stockAlerts, averages.stockAlerts)
  }));

  return { records: normalized, averages, rankings, insights };
}

function rankDescending(records, target, metric) {
  return 1 + records.filter(
    r => r.metrics[metric] > target.metrics[metric]
  ).length;
}

function percentageDelta(value, average) {
  if (!average) return value ? null : 0;
  return ((value - average) / Math.abs(average)) * 100;
}

export function assertBenchmarkScope(context, businessIds = []) {
  const allowed = new Set(context?.allowedBusinessIds || []);
  for (const id of businessIds) {
    if (!allowed.has(id)) throw new Error('Périmètre de benchmark interdit');
  }
  return true;
}

export function buildBenchmarkSummary(result) {
  return {
    participants: result.records.length,
    averages: result.averages,
    topRevenue: result.rankings
      .filter(r => r.revenueRank === 1)
      .map(r => r.name),
    topMargin: result.rankings
      .filter(r => r.marginRank === 1)
      .map(r => r.name)
  };
}
