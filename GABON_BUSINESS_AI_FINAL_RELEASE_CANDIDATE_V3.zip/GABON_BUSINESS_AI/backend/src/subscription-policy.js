
// Server-side subscription policy.
// The client must never be trusted to decide whether paid features are enabled.

function isActiveSubscription(subscription, now = new Date()) {
  if (!subscription || subscription.status !== 'ACTIVE') return false;
  if (!subscription.expires_at) return false;
  return new Date(subscription.expires_at).getTime() > now.getTime();
}

function assertPaidAccess(subscription, now = new Date()) {
  if (!isActiveSubscription(subscription, now)) {
    const err = new Error('SUBSCRIPTION_REQUIRED');
    err.statusCode = 402;
    throw err;
  }
  return true;
}

module.exports = { isActiveSubscription, assertPaidAccess };
