export const V27_DIRECTOR_ROUTES = {
  ask: 'POST /api/director/ask',
  plan: 'POST /api/director/plan',
  confirm: 'POST /api/director/confirm',
  history: 'GET /api/director/history'
};
