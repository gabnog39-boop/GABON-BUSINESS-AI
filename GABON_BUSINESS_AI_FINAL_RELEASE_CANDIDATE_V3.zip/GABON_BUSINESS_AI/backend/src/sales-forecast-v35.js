const SCENARIOS = {
  PRUDENT: { growth: -0.05, confidence: 65 },
  CENTRAL: { growth: 0.00, confidence: 72 },
  DYNAMIQUE: { growth: 0.08, confidence: 58 }
};

function safeNumber(value) {
  const n = Number(value);
  return Number.isFinite(n) ? n : 0;
}

export function buildSalesForecast(input = {}) {
  if (!input.businessId) throw new Error('businessId obligatoire');

  const scenario = String(input.scenario || 'CENTRAL').toUpperCase();
  if (!SCENARIOS[scenario]) throw new Error('Scénario invalide');

  const revenue = Math.max(0, safeNumber(input.baselineRevenue));
  const salesCount = Math.max(0, safeNumber(input.baselineSalesCount));
  const targetRevenue = Math.max(0, safeNumber(input.targetRevenue));

  const growth = safeNumber(input.growthOverridePct) / 100 || SCENARIOS[scenario].growth;
  const projectedRevenue = revenue * (1 + growth);
  const projectedSalesCount = salesCount * (1 + growth);

  const targetGap = targetRevenue
    ? projectedRevenue - targetRevenue
    : null;

  const risks = [];
  if (projectedRevenue < revenue) {
    risks.push('Projection inférieure à la période de référence.');
  }
  if (targetRevenue && projectedRevenue < targetRevenue) {
    risks.push('Objectif de chiffre d’affaires potentiellement non atteint.');
  }
  if (salesCount === 0) {
    risks.push('Historique de ventes insuffisant pour une projection robuste.');
  }

  const recommendations = [];
  if (targetGap !== null && targetGap < 0) {
    recommendations.push('Renforcer la prospection et le suivi des opportunités commerciales.');
  }
  if (projectedRevenue >= revenue) {
    recommendations.push('Surveiller la capacité de stock et de livraison si la demande augmente.');
  }
  recommendations.push('Comparer régulièrement la projection au réalisé et recalculer avec les nouvelles données.');

  return {
    businessId: input.businessId,
    siteId: input.siteId || null,
    forecastStart: input.forecastStart || null,
    forecastEnd: input.forecastEnd || null,
    baselineRevenue: Number(revenue.toFixed(2)),
    projectedRevenue: Number(projectedRevenue.toFixed(2)),
    projectedSalesCount: Number(projectedSalesCount.toFixed(2)),
    growthPct: Number((growth * 100).toFixed(2)),
    targetRevenue: targetRevenue || null,
    targetGap: targetGap === null ? null : Number(targetGap.toFixed(2)),
    confidencePct: SCENARIOS[scenario].confidence,
    scenario,
    assumptions: {
      method: 'baseline_growth_scenario',
      baselineRevenue: revenue,
      baselineSalesCount: salesCount
    },
    risks,
    recommendations
  };
}

export function compareForecastScenarios(input = {}) {
  return ['PRUDENT', 'CENTRAL', 'DYNAMIQUE'].map(scenario =>
    buildSalesForecast({ ...input, scenario })
  );
}

export function assertForecastScope(context, businessId, siteId = null) {
  if (!context?.allowedBusinessIds?.includes(businessId)) {
    throw new Error('Entreprise non autorisée');
  }
  if (siteId && context.allowedSiteIds && !context.allowedSiteIds.includes(siteId)) {
    throw new Error('Site non autorisé');
  }
  return true;
}
