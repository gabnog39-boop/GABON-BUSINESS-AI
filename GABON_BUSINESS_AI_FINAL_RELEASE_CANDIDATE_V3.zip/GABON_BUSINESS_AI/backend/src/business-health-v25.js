const DIMENSIONS = [
  'cashflow','profitability','receivables','sales',
  'stock','expenses','goals','commercialActivity'
];

const WEIGHTS = {
  cashflow: .18, profitability: .18, receivables: .12,
  sales: .14, stock: .10, expenses: .10,
  goals: .08, commercialActivity: .10
};

const clamp = (v) => Math.max(0, Math.min(100, Number(v) || 0));

export function calculateBusinessHealth(input = {}) {
  const dimensions = Object.fromEntries(
    DIMENSIONS.map(k => [k, clamp(input[k] ?? 50)])
  );

  const score = Math.round(
    DIMENSIONS.reduce((sum, k) => sum + dimensions[k] * WEIGHTS[k], 0) * 100
  ) / 100;

  let level = 'CRITICAL';
  if (score >= 80) level = 'EXCELLENT';
  else if (score >= 65) level = 'GOOD';
  else if (score >= 50) level = 'WATCH';
  else if (score >= 35) level = 'RISK';

  const priorities = Object.entries(dimensions)
    .filter(([, v]) => v < 60)
    .sort((a, b) => a[1] - b[1])
    .slice(0, 5)
    .map(([dimension, value]) => ({
      dimension, score: value, priority: value < 35 ? 'HIGH' : 'MEDIUM'
    }));

  return { score, level, dimensions, priorities };
}

export function explainHealth(score) {
  if (score >= 80) return 'Situation globalement solide.';
  if (score >= 65) return 'Situation saine avec quelques axes d’amélioration.';
  if (score >= 50) return 'Situation à surveiller.';
  if (score >= 35) return 'Risque élevé; traiter les priorités rapidement.';
  return 'Situation critique; analyse détaillée nécessaire.';
}
