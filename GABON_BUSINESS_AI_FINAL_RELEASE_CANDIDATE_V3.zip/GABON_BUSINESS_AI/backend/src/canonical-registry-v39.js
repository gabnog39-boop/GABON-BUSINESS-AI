/**
 * GABON BUSINESS AI — V39 canonical integration registry
 * Loads available domain services from one server-side registry.
 * Services remain isolated; missing optional modules do not crash startup.
 */
const path = require("path");

const SERVICE_FILES = [
  "anomaly-detector-v36.js",
  "api-contract-v13.js",
  "api-contract-v20.js",
  "api-contract-v21.js",
  "api-contract-v22.js",
  "api-contract-v23.js",
  "api-contract-v24.js",
  "api-contract-v25.js",
  "api-contract-v26.js",
  "api-contract-v27.js",
  "api-contract-v28.js",
  "api-contract-v29.js",
  "api-contract-v30.js",
  "api-contract-v31.js",
  "api-contract-v32.js",
  "api-contract-v33.js",
  "api-contract-v34.js",
  "api-contract-v35.js",
  "api-contract-v36.js",
  "api-contract-v37.js",
  "api-contract-v8.js",
  "auth-policy.js",
  "auth-service-v10.js",
  "automation-advanced-v28.js",
  "automation-service-v15.js",
  "benchmarking-v31.js",
  "business-health-v25.js",
  "command-center-v37.js",
  "commerce-service-v11.js",
  "commercial-director-v17.js",
  "customer-intelligence-v34.js",
  "dashboard-reports-memory-v13.js",
  "db.js",
  "director-ai-v14.js",
  "document-generator-v22.js",
  "document-intelligence-v21.js",
  "finance-director-v18.js",
  "finance-service-v12.js",
  "marketing-director-v20.js",
  "multi-tenant-v30.js",
  "negotiation-assistant-v33.js",
  "notification-engine-v29.js",
  "opportunity-engine-v32.js",
  "owner-policy.js",
  "professional-memory-v23.js",
  "sales-forecast-v35.js",
  "server-v10.js",
  "server-v9.js",
  "stock-director-v19.js",
  "strategic-simulator-v16.js",
  "strategic-simulator-v26.js",
  "subscription-policy.js",
  "unified-director-v27.js",
  "voice-assistant-v24.js"
];

function loadOptionalServices(baseDir) {
  const loaded = {};
  for (const file of SERVICE_FILES) {
    try {
      loaded[file.replace(/\.js$/, "")] = require(path.join(baseDir, file));
    } catch (error) {
      loaded[file.replace(/\.js$/, "")] = {
        available: false,
        error: error.message
      };
    }
  }
  return loaded;
}

module.exports = { SERVICE_FILES, loadOptionalServices };
