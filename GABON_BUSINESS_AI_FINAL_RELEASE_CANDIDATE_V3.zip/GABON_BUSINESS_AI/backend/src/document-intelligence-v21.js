const TYPES = new Set([
  'INVOICE',
  'QUOTE',
  'RECEIPT',
  'PURCHASE_ORDER',
  'DELIVERY_NOTE',
  'EXPENSE_RECEIPT',
  'CONTRACT',
  'OTHER'
]);

export function classifyDocument(documentType) {
  const type = String(documentType || 'OTHER').toUpperCase();
  return TYPES.has(type) ? type : 'OTHER';
}

export function extractDocumentFields(input = {}) {
  const data = {
    documentNumber: input.documentNumber ?? null,
    issueDate: input.issueDate ?? null,
    dueDate: input.dueDate ?? null,
    supplierName: input.supplierName ?? null,
    customerName: input.customerName ?? null,
    taxId: input.taxId ?? null,
    currency: input.currency ?? 'XAF',
    subtotal: input.subtotal ?? null,
    tax: input.tax ?? null,
    total: input.total ?? null,
    paymentStatus: input.paymentStatus ?? null
  };

  const missing = [];
  if (!data.issueDate) missing.push('issueDate');
  if (data.total === null || data.total === undefined) missing.push('total');

  return { data, missing };
}

export function analyzeDocumentConsistency(data = {}) {
  const findings = [];

  if (data.subtotal != null && data.tax != null && data.total != null) {
    const expected = Number(data.subtotal) + Number(data.tax);
    const actual = Number(data.total);
    if (Number.isFinite(expected) && Number.isFinite(actual) &&
        Math.abs(expected - actual) > 0.01) {
      findings.push({
        type: 'AMOUNT_INCONSISTENCY',
        severity: 'WARNING',
        message: 'Le total ne correspond pas au sous-total augmenté de la taxe.',
        requiresConfirmation: true
      });
    }
  }

  if (data.dueDate && data.issueDate && String(data.dueDate) < String(data.issueDate)) {
    findings.push({
      type: 'DATE_INCONSISTENCY',
      severity: 'WARNING',
      message: 'La date d’échéance semble antérieure à la date du document.',
      requiresConfirmation: true
    });
  }

  return findings;
}

export function buildDocumentSummary({ fileName, documentType, extracted }) {
  return {
    fileName,
    documentType: classifyDocument(documentType),
    extractedFields: extracted?.data || {},
    missingFields: extracted?.missing || [],
    readyForHumanReview: true
  };
}
