export const V34_CUSTOMER_INTELLIGENCE_ROUTES = {
  calculate: 'POST /api/customers/:customerId/intelligence/calculate',
  detail: 'GET /api/customers/:customerId/intelligence',
  list: 'GET /api/customers/intelligence',
  actions: 'GET /api/customers/:customerId/intelligence/actions'
};
