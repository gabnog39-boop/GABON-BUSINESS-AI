const { Pool } = require('pg');

function makeV13Service(pool) {
  return {
    async dashboard(businessId) {
      const q = await pool.query(`
        SELECT
          COALESCE((SELECT SUM(total) FROM invoices WHERE business_id=$1),0) AS invoiced,
          COALESCE((SELECT SUM(amount) FROM payments WHERE business_id=$1),0) AS paid,
          COALESCE((SELECT SUM(amount) FROM expenses WHERE business_id=$1),0) AS expenses,
          COALESCE((SELECT SUM(total_amount) FROM purchase_orders WHERE business_id=$1
                    AND status IN ('RECEIVED','PARTIAL')),0) AS purchases
      `, [businessId]);
      const r = q.rows[0];
      const invoiced = Number(r.invoiced);
      const paid = Number(r.paid);
      const expenses = Number(r.expenses);
      const purchases = Number(r.purchases);
      return {
        invoiced, paid, expenses, purchases,
        receivables: Math.max(invoiced - paid, 0),
        estimatedOperatingResult: paid - expenses - purchases
      };
    },

    async saveReport(businessId, reportType, periodStart, periodEnd, payload, generatedBy='system') {
      const q = await pool.query(`
        INSERT INTO business_reports
          (business_id, report_type, period_start, period_end, payload, generated_by)
        VALUES ($1,$2,$3,$4,$5,$6)
        RETURNING *
      `, [businessId, reportType, periodStart, periodEnd, payload, generatedBy]);
      return q.rows[0];
    },

    async listReports(businessId) {
      const q = await pool.query(`
        SELECT id, report_type, period_start, period_end, generated_by, created_at
        FROM business_reports
        WHERE business_id=$1
        ORDER BY created_at DESC
        LIMIT 100
      `, [businessId]);
      return q.rows;
    },

    async upsertMemory(businessId, memoryType, memoryKey, memoryValue, importance=50) {
      const q = await pool.query(`
        INSERT INTO ai_business_memory
          (business_id, memory_type, memory_key, memory_value, importance)
        VALUES ($1,$2,$3,$4,$5)
        ON CONFLICT (business_id, memory_type, memory_key)
        DO UPDATE SET memory_value=EXCLUDED.memory_value,
                      importance=EXCLUDED.importance,
                      updated_at=NOW()
        RETURNING *
      `, [businessId, memoryType, memoryKey, memoryValue, importance]);
      return q.rows[0];
    },

    async getMemory(businessId, limit=50) {
      const q = await pool.query(`
        SELECT memory_type, memory_key, memory_value, importance, updated_at
        FROM ai_business_memory
        WHERE business_id=$1
        ORDER BY importance DESC, updated_at DESC
        LIMIT $2
      `, [businessId, limit]);
      return q.rows;
    }
  };
}

module.exports = { makeV13Service };
