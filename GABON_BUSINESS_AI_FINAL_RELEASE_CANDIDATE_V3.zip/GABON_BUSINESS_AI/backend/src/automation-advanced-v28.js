const ACTIONS = {
  CREATE_REMINDER: { confirmation: false },
  PREPARE_CUSTOMER_FOLLOWUP: { confirmation: false },
  CREATE_STOCK_ALERT: { confirmation: false },
  GENERATE_REPORT: { confirmation: false },
  CREATE_TASK: { confirmation: false },
  RECORD_PAYMENT: { confirmation: true },
  SEND_EXTERNAL_MESSAGE: { confirmation: true },
  CREATE_PURCHASE_ORDER: { confirmation: true },
  CREATE_EXPENSE: { confirmation: true },
  DELETE_DATA: { confirmation: true }
};

const TRIGGERS = new Set([
  'SCHEDULE',
  'LOW_STOCK',
  'OVERDUE_INVOICE',
  'PAYMENT_RECEIVED',
  'DAILY_CHECK',
  'WEEKLY_CHECK',
  'MONTHLY_CHECK',
  'BUSINESS_EVENT'
]);

export function validateRule(input = {}) {
  if (!input.name) throw new Error('Nom de règle obligatoire');
  if (!TRIGGERS.has(String(input.triggerType || '').toUpperCase())) {
    throw new Error('Déclencheur non supporté');
  }

  const actionType = String(input.actionType || '').toUpperCase();
  if (!ACTIONS[actionType]) throw new Error('Action non supportée');

  return {
    name: input.name,
    triggerType: String(input.triggerType).toUpperCase(),
    conditions: input.conditions || {},
    actionType,
    actionPayload: input.actionPayload || {},
    enabled: input.enabled !== false,
    requiresConfirmation: ACTIONS[actionType].confirmation
  };
}

export function evaluateRule(rule, context = {}) {
  if (!rule || !rule.enabled) return { matched: false, reason: 'DISABLED' };

  // Le moteur de production devra remplacer cette évaluation
  // par des conditions typées et validées côté serveur.
  return {
    matched: true,
    actionType: rule.actionType,
    actionPayload: rule.actionPayload,
    requiresConfirmation: Boolean(rule.requiresConfirmation),
    context
  };
}

export function proposeExecution(rule, context = {}) {
  const evaluation = evaluateRule(rule, context);
  if (!evaluation.matched) return evaluation;

  return {
    status: evaluation.requiresConfirmation
      ? 'AWAITING_CONFIRMATION'
      : 'READY',
    proposedAction: {
      type: evaluation.actionType,
      payload: evaluation.actionPayload
    }
  };
}

export function confirmExecution(proposal, confirmed = false) {
  if (!proposal) throw new Error('Proposition manquante');
  if (proposal.status !== 'AWAITING_CONFIRMATION') {
    return { ...proposal, status: 'READY' };
  }
  if (confirmed !== true) throw new Error('Confirmation humaine obligatoire');

  return { ...proposal, status: 'CONFIRMED' };
}
