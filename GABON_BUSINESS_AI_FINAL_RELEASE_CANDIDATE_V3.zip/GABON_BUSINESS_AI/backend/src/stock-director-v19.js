// V19 — Directeur Stock & Achats IA
// Decision-support layer. It proposes purchases; it does not place orders automatically.

function makeStockDirector(pool) {
  async function analyze(businessId) {
    const q = await pool.query(`
      SELECT
        p.id,
        p.name,
        p.stock_quantity,
        p.low_stock_threshold,
        COALESCE(SUM(ii.quantity) FILTER (
          WHERE i.created_at >= NOW() - INTERVAL '30 days'
        ),0) AS sold_30d
      FROM products p
      LEFT JOIN invoice_items ii ON ii.product_id=p.id
      LEFT JOIN invoices i ON i.id=ii.invoice_id AND i.business_id=$1
      WHERE p.business_id=$1
      GROUP BY p.id, p.name, p.stock_quantity, p.low_stock_threshold
      ORDER BY sold_30d DESC
    `, [businessId]);

    return q.rows.map(r => {
      const stock = Number(r.stock_quantity || 0);
      const threshold = Number(r.low_stock_threshold || 0);
      const sold30 = Number(r.sold_30d || 0);
      const avgDaily = sold30 / 30;
      const daysCover = avgDaily > 0 ? stock / avgDaily : null;

      let recommendation = null;
      if (stock <= threshold) {
        const target = Math.max(threshold * 2, avgDaily * 30);
        recommendation = {
          type: 'REORDER',
          priority: stock <= 0 ? 'URGENT' : 'HIGH',
          suggestedQuantity: Math.max(Math.ceil(target - stock), 0),
          reason: stock <= 0
            ? 'Rupture de stock détectée.'
            : 'Stock au seuil ou sous le seuil configuré.'
        };
      } else if (daysCover !== null && daysCover < 15) {
        recommendation = {
          type: 'REORDER_SOON',
          priority: 'HIGH',
          suggestedQuantity: Math.max(Math.ceil(avgDaily * 30 - stock), 0),
          reason: 'La couverture estimée du stock est inférieure à 15 jours.'
        };
      }

      return {
        productId: r.id,
        product: r.name,
        stock,
        threshold,
        sold30d: sold30,
        averageDailySales: avgDaily,
        estimatedDaysOfCover: daysCover,
        recommendation
      };
    });
  }

  async function saveRecommendation(businessId, item) {
    if (!item.recommendation) return null;
    const q = await pool.query(`
      INSERT INTO stock_ai_recommendations
        (business_id,product_id,recommendation_type,priority,suggested_quantity,reason,payload)
      VALUES ($1,$2,$3,$4,$5,$6,$7)
      RETURNING *
    `, [
      businessId, item.productId, item.recommendation.type,
      item.recommendation.priority, item.recommendation.suggestedQuantity,
      item.recommendation.reason, item
    ]);
    return q.rows[0];
  }

  return { analyze, saveRecommendation };
}

module.exports = { makeStockDirector };
