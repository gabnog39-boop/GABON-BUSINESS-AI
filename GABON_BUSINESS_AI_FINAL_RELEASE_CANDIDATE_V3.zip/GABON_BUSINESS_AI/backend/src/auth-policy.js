
// V8 authorization policy.
// Authentication token verification must be implemented by the production auth adapter.
// These functions centralize tenant and role checks so routes do not duplicate policy.

const BUSINESS_ROLES = new Set(["OWNER", "ADMIN", "MANAGER", "EMPLOYEE"]);
const WRITE_ROLES = new Set(["OWNER", "ADMIN", "MANAGER"]);

function requireBusinessMember(ctx, businessId) {
  if (!ctx?.userId || !ctx?.businessId || ctx.businessId !== businessId) {
    const err = new Error("FORBIDDEN_TENANT");
    err.statusCode = 403;
    throw err;
  }
  if (!BUSINESS_ROLES.has(ctx.role)) {
    const err = new Error("FORBIDDEN_ROLE");
    err.statusCode = 403;
    throw err;
  }
}

function requireWriteRole(ctx) {
  if (!WRITE_ROLES.has(ctx?.role)) {
    const err = new Error("WRITE_PERMISSION_REQUIRED");
    err.statusCode = 403;
    throw err;
  }
}

function requireOwner(ctx) {
  if (ctx?.platformRole !== "OWNER") {
    const err = new Error("PLATFORM_OWNER_REQUIRED");
    err.statusCode = 403;
    throw err;
  }
}

module.exports = { requireBusinessMember, requireWriteRole, requireOwner };
