const ROLES = new Set([
  'OWNER', 'ADMIN', 'MANAGER', 'ACCOUNTANT', 'EMPLOYEE', 'VIEWER'
]);

export function validateSite(input = {}) {
  if (!input.businessId) throw new Error('businessId obligatoire');
  if (!input.name) throw new Error('Nom du site obligatoire');
  if (!input.code) throw new Error('Code du site obligatoire');

  return {
    businessId: input.businessId,
    name: String(input.name),
    code: String(input.code).toUpperCase(),
    address: input.address || null,
    active: input.active !== false
  };
}

export function validateBusinessAccess(input = {}) {
  const role = String(input.accessRole || 'VIEWER').toUpperCase();
  if (!ROLES.has(role)) throw new Error('Rôle multi-entreprises invalide');

  return {
    platformUserId: input.platformUserId,
    businessId: input.businessId,
    accessRole: role,
    active: input.active !== false
  };
}

export function assertBusinessScope(context, businessId) {
  if (!context?.allowedBusinessIds?.includes(businessId)) {
    throw new Error('Accès à cette entreprise interdit');
  }
  return true;
}

export function consolidateAuthorizedBusinesses(records = [], allowedBusinessIds = []) {
  return records.filter(r => allowedBusinessIds.includes(r.businessId));
}

export function consolidateSites(records = [], businessId) {
  return records.filter(r => r.businessId === businessId);
}
