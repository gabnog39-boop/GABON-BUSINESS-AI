// V17 — Directeur commercial IA
// Generates commercial intelligence and proposed actions.
// It does not send messages or modify customer data without confirmation.

function makeCommercialDirector(pool) {
  async function pipeline(businessId) {
    const q = await pool.query(`
      SELECT stage,
             COUNT(*)::int AS count,
             COALESCE(SUM(estimated_value),0) AS value,
             COALESCE(SUM(estimated_value * probability / 100),0) AS weighted_value
      FROM sales_opportunities
      WHERE business_id=$1
      GROUP BY stage
      ORDER BY stage
    `, [businessId]);
    return q.rows;
  }

  async function createOpportunity(businessId, data) {
    const q = await pool.query(`
      INSERT INTO sales_opportunities
        (business_id,customer_id,title,stage,estimated_value,probability,next_action,next_action_at)
      VALUES ($1,$2,$3,$4,$5,$6,$7,$8)
      RETURNING *
    `, [
      businessId, data.customerId || null, data.title,
      data.stage || 'NEW', Number(data.estimatedValue || 0),
      Number(data.probability || 0), data.nextAction || null,
      data.nextActionAt || null
    ]);
    return q.rows[0];
  }

  async function proposeAction(businessId, data) {
    const q = await pool.query(`
      INSERT INTO commercial_actions
        (business_id,customer_id,action_type,priority,reason,payload)
      VALUES ($1,$2,$3,$4,$5,$6)
      RETURNING *
    `, [
      businessId, data.customerId || null, data.actionType,
      data.priority || 'MEDIUM', data.reason, data.payload || {}
    ]);
    return q.rows[0];
  }

  async function analysis(businessId) {
    const pipe = await pipeline(businessId);
    const q = await pool.query(`
      SELECT
        (SELECT COUNT(*) FROM customers WHERE business_id=$1) AS customers,
        (SELECT COUNT(*) FROM invoices WHERE business_id=$1 AND status <> 'PAID') AS unpaid_invoices,
        (SELECT COUNT(*) FROM sales_opportunities WHERE business_id=$1 AND stage NOT IN ('WON','LOST')) AS open_opportunities
    `, [businessId]);

    const s = q.rows[0];
    const recommendations = [];

    if (Number(s.unpaid_invoices) > 0) {
      recommendations.push({
        priority: 'HIGH',
        type: 'FOLLOW_UP',
        title: 'Relancer les clients avec factures impayées',
        action: 'Préparer les relances et les soumettre à confirmation.'
      });
    }

    if (Number(s.open_opportunities) === 0) {
      recommendations.push({
        priority: 'MEDIUM',
        type: 'PROSPECTION',
        title: 'Créer de nouvelles opportunités commerciales',
        action: 'Préparer un plan de prospection.'
      });
    }

    return {
      indicators: {
        customers: Number(s.customers),
        unpaidInvoices: Number(s.unpaid_invoices),
        openOpportunities: Number(s.open_opportunities)
      },
      pipeline: pipe,
      recommendations
    };
  }

  return { pipeline, createOpportunity, proposeAction, analysis };
}

module.exports = { makeCommercialDirector };
