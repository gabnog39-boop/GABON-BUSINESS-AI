export const V30_MULTI_TENANT_ROUTES = {
  businesses: 'GET /api/businesses',
  createBusiness: 'POST /api/businesses',
  businessDetail: 'GET /api/businesses/:businessId',
  sites: 'GET /api/businesses/:businessId/sites',
  createSite: 'POST /api/businesses/:businessId/sites',
  updateSite: 'PATCH /api/sites/:siteId',
  access: 'GET /api/businesses/:businessId/access',
  grantAccess: 'POST /api/businesses/:businessId/access',
  revokeAccess: 'POST /api/businesses/:businessId/access/:accessId/revoke',
  consolidatedDashboard: 'GET /api/businesses/consolidated/dashboard'
};
