const PRIORITY = ['CRITICAL', 'HIGH', 'NORMAL', 'LOW'];

const CHANNELS = new Set([
  'IN_APP',
  'EMAIL',
  'SMS',
  'PUSH',
  'WEBHOOK'
]);

export function normalizeNotification(input = {}) {
  const priority = String(input.priority || 'NORMAL').toUpperCase();
  if (!PRIORITY.includes(priority)) throw new Error('Priorité invalide');

  return {
    category: String(input.category || 'GENERAL').toUpperCase(),
    priority,
    title: String(input.title || 'Notification'),
    message: String(input.message || ''),
    payload: input.payload || {},
    dedupeKey: input.dedupeKey || null,
    status: 'UNREAD'
  };
}

export function shouldDeliver(notification, preference = {}) {
  if (!notification) return false;
  if (preference.enabled === false) return false;
  return true;
}

export function selectChannels(preferences = [], defaultChannel = 'IN_APP') {
  const enabled = preferences
    .filter(p => p.enabled !== false && CHANNELS.has(String(p.channel).toUpperCase()))
    .map(p => String(p.channel).toUpperCase());

  return [...new Set(enabled.length ? enabled : [defaultChannel])];
}

export function isDuplicate(existing = [], notification) {
  if (!notification?.dedupeKey) return false;
  return existing.some(n =>
    n.dedupeKey === notification.dedupeKey &&
    n.status !== 'ARCHIVED'
  );
}

export function rankNotifications(notifications = []) {
  const weight = Object.fromEntries(PRIORITY.map((p, i) => [p, 4 - i]));
  return [...notifications].sort(
    (a, b) => (weight[b.priority] || 0) - (weight[a.priority] || 0)
  );
}
