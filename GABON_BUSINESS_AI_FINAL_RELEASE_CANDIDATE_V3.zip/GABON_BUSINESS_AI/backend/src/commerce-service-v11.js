
const { pool } = require("./db");

async function createInvoice({businessId, customerId, number, items}) {
  const client = await pool.connect();
  try {
    await client.query("BEGIN");

    if (!Array.isArray(items) || items.length === 0) {
      throw Object.assign(new Error("INVOICE_ITEMS_REQUIRED"), {statusCode:400});
    }

    const productIds = items.filter(x => x.product_id).map(x => x.product_id);
    const products = productIds.length
      ? await client.query(
          `SELECT id, name, unit_price_xaf, stock_qty
           FROM products
           WHERE business_id=$1 AND id = ANY($2::uuid[]) AND active=true
           FOR UPDATE`,
          [businessId, productIds]
        )
      : {rows: []};

    const byId = new Map(products.rows.map(p => [p.id, p]));
    let total = 0;
    const normalized = [];

    for (const item of items) {
      const qty = Number(item.quantity);
      if (!Number.isFinite(qty) || qty <= 0) throw Object.assign(new Error("INVALID_QUANTITY"), {statusCode:400});

      const product = item.product_id ? byId.get(item.product_id) : null;
      if (item.product_id && !product) throw Object.assign(new Error("PRODUCT_NOT_FOUND"), {statusCode:404});

      const price = Number(item.unit_price_xaf ?? product?.unit_price_xaf ?? 0);
      if (!Number.isFinite(price) || price < 0) throw Object.assign(new Error("INVALID_PRICE"), {statusCode:400});

      if (product && Number(product.stock_qty) < qty)
        throw Object.assign(new Error("INSUFFICIENT_STOCK"), {statusCode:409});

      const line = Math.round(qty * price);
      total += line;
      normalized.push({
        product_id: product?.id ?? null,
        description: item.description || product?.name || "Article",
        quantity: qty,
        unit_price_xaf: price,
        line_total_xaf: line
      });
    }

    const inv = await client.query(
      `INSERT INTO invoices(business_id,customer_id,number,status,total_xaf)
       VALUES($1,$2,$3,'ISSUED',$4)
       RETURNING id,number,status,total_xaf,created_at`,
      [businessId, customerId || null, number, total]
    );

    for (const item of normalized) {
      await client.query(
        `INSERT INTO invoice_items(invoice_id,product_id,description,quantity,unit_price_xaf,line_total_xaf)
         VALUES($1,$2,$3,$4,$5,$6)`,
        [inv.rows[0].id,item.product_id,item.description,item.quantity,item.unit_price_xaf,item.line_total_xaf]
      );

      if (item.product_id) {
        await client.query(
          `UPDATE products SET stock_qty=stock_qty-$1 WHERE id=$2 AND business_id=$3`,
          [item.quantity,item.product_id,businessId]
        );
        await client.query(
          `INSERT INTO stock_movements(business_id,product_id,type,quantity,reference)
           VALUES($1,$2,'OUT',$3,$4)`,
          [businessId,item.product_id,item.quantity,`INVOICE:${inv.rows[0].id}`]
        );
      }
    }

    await client.query("COMMIT");
    return inv.rows[0];
  } catch (e) {
    await client.query("ROLLBACK");
    throw e;
  } finally {
    client.release();
  }
}

async function recordPayment({businessId, invoiceId, amountXaf, provider, providerReference, idempotencyKey}) {
  const client = await pool.connect();
  try {
    await client.query("BEGIN");

    const existing = await client.query(
      `SELECT id,invoice_id,amount_xaf FROM payments
       WHERE business_id=$1 AND idempotency_key=$2`,
      [businessId,idempotencyKey]
    );
    if (existing.rowCount) {
      await client.query("COMMIT");
      return {duplicate:true, payment:existing.rows[0]};
    }

    const inv = await client.query(
      `SELECT id,total_xaf,status FROM invoices
       WHERE business_id=$1 AND id=$2 FOR UPDATE`,
      [businessId,invoiceId]
    );
    if (!inv.rowCount) throw Object.assign(new Error("INVOICE_NOT_FOUND"),{statusCode:404});

    const amount = Number(amountXaf);
    if (!Number.isFinite(amount) || amount <= 0) throw Object.assign(new Error("INVALID_PAYMENT"),{statusCode:400});

    const paid = await client.query(
      `SELECT COALESCE(sum(amount_xaf),0)::bigint AS total
       FROM payments WHERE business_id=$1 AND invoice_id=$2`,
      [businessId,invoiceId]
    );
    const already = Number(paid.rows[0].total);
    if (already + amount > Number(inv.rows[0].total_xaf))
      throw Object.assign(new Error("PAYMENT_EXCEEDS_BALANCE"),{statusCode:409});

    const p = await client.query(
      `INSERT INTO payments(business_id,invoice_id,amount_xaf,provider,provider_reference,idempotency_key)
       VALUES($1,$2,$3,$4,$5,$6)
       RETURNING id,invoice_id,amount_xaf,provider,provider_reference,created_at`,
      [businessId,invoiceId,amount,provider||null,providerReference||null,idempotencyKey]
    );

    const newTotal = already + amount;
    const status = newTotal >= Number(inv.rows[0].total_xaf) ? "PAID" : "PARTIAL";
    await client.query("UPDATE invoices SET status=$1 WHERE id=$2", [status,invoiceId]);

    await client.query("COMMIT");
    return {duplicate:false,payment:p.rows[0],invoice_status:status};
  } catch(e) {
    await client.query("ROLLBACK");
    throw e;
  } finally {
    client.release();
  }
}

module.exports = {createInvoice,recordPayment};
