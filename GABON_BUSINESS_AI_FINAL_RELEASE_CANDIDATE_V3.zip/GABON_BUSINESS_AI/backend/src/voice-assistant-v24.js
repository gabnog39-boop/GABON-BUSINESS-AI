const READ_ONLY_INTENTS = new Set([
  'GET_DASHBOARD',
  'GET_RECEIVABLES',
  'GET_TOP_PRODUCTS',
  'GET_STOCK_ALERTS',
  'GET_REPORT',
  'GET_CUSTOMERS'
]);

const SENSITIVE_INTENTS = new Set([
  'CREATE_INVOICE',
  'CREATE_QUOTE',
  'RECORD_PAYMENT',
  'CREATE_EXPENSE',
  'CREATE_PURCHASE_ORDER',
  'SEND_DOCUMENT',
  'CHANGE_SUBSCRIPTION',
  'DELETE_DATA'
]);

export function classifyVoiceIntent(intent) {
  const value = String(intent || '').toUpperCase();
  if (READ_ONLY_INTENTS.has(value)) return 'READ_ONLY';
  if (SENSITIVE_INTENTS.has(value)) return 'SENSITIVE';
  return 'UNKNOWN';
}

export function prepareVoiceCommand(input = {}) {
  if (!input.transcript) throw new Error('Transcription obligatoire');

  const sensitivity = classifyVoiceIntent(input.intent);

  return {
    transcript: String(input.transcript),
    intent: input.intent || null,
    parameters: input.parameters || {},
    sensitivity,
    status: sensitivity === 'SENSITIVE' ? 'AWAITING_CONFIRMATION' : 'READY'
  };
}

export function confirmVoiceCommand(command, confirmationToken) {
  if (!command || command.sensitivity !== 'SENSITIVE') {
    throw new Error('Cette commande ne nécessite pas de confirmation sensible');
  }
  if (!confirmationToken || confirmationToken !== command.confirmationToken) {
    throw new Error('Confirmation invalide');
  }

  return {
    ...command,
    status: 'CONFIRMED',
    confirmedAt: new Date().toISOString()
  };
}

export function rejectVoiceCommand(command) {
  return {
    ...command,
    status: 'REJECTED'
  };
}
