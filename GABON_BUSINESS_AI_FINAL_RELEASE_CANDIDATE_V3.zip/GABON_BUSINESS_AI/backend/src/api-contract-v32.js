export const V32_OPPORTUNITY_ROUTES = {
  detect: 'POST /api/opportunities/detect',
  list: 'GET /api/opportunities',
  detail: 'GET /api/opportunities/:opportunityId',
  approve: 'POST /api/opportunities/:opportunityId/approve',
  reject: 'POST /api/opportunities/:opportunityId/reject'
};
