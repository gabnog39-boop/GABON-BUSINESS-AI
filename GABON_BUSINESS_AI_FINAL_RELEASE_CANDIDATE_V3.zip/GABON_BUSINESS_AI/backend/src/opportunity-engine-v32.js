const TYPES = new Set([
  'CROSS_SELL',
  'UPSELL',
  'NEW_PRODUCT',
  'NEW_SERVICE',
  'CUSTOMER_SEGMENT',
  'RETENTION',
  'SITE_EXPANSION',
  'STOCK_OPPORTUNITY'
]);

const PRIORITIES = new Set(['CRITICAL', 'HIGH', 'NORMAL', 'LOW']);

export function normalizeOpportunity(input = {}) {
  const type = String(input.opportunityType || 'NEW_SERVICE').toUpperCase();
  const priority = String(input.priority || 'NORMAL').toUpperCase();

  if (!TYPES.has(type)) throw new Error('Type d’opportunité invalide');
  if (!PRIORITIES.has(priority)) throw new Error('Priorité invalide');
  if (!input.businessId) throw new Error('businessId obligatoire');
  if (!input.title) throw new Error('Titre obligatoire');

  return {
    businessId: input.businessId,
    siteId: input.siteId || null,
    opportunityType: type,
    title: String(input.title),
    description: String(input.description || ''),
    estimatedValue: input.estimatedValue == null ? null : Number(input.estimatedValue),
    confidencePct: input.confidencePct == null ? null : Number(input.confidencePct),
    priority,
    status: 'PROPOSED',
    sourceData: input.sourceData || {}
  };
}

export function detectOpportunities(context = {}) {
  const opportunities = [];
  const products = Array.isArray(context.products) ? context.products : [];
  const customers = Array.isArray(context.customers) ? context.customers : [];

  for (const product of products) {
    const sales = Number(product.sales30d || 0);
    const stock = Number(product.stockQty || 0);
    if (sales > 0 && stock <= Number(product.lowStockThreshold || 0)) {
      opportunities.push(normalizeOpportunity({
        businessId: context.businessId,
        siteId: context.siteId,
        opportunityType: 'STOCK_OPPORTUNITY',
        title: `Sécuriser les ventes de ${product.name || 'ce produit'}`,
        description: 'La demande récente est active alors que le stock est proche du seuil.',
        priority: 'HIGH',
        confidencePct: 85,
        sourceData: { productId: product.id, sales30d: sales, stockQty: stock }
      }));
    }
  }

  for (const customer of customers) {
    const total = Number(customer.totalPurchases || 0);
    const days = Number(customer.daysSinceLastPurchase || 0);
    if (total > 0 && days >= 60) {
      opportunities.push(normalizeOpportunity({
        businessId: context.businessId,
        siteId: context.siteId,
        opportunityType: 'RETENTION',
        title: `Relancer ${customer.name || 'un client inactif'}`,
        description: 'Le client possède un historique d’achat mais n’a pas acheté récemment.',
        priority: 'HIGH',
        confidencePct: 80,
        sourceData: { customerId: customer.id, daysSinceLastPurchase: days }
      }));
    }
  }

  if (products.length >= 2) {
    opportunities.push(normalizeOpportunity({
      businessId: context.businessId,
      siteId: context.siteId,
      opportunityType: 'CROSS_SELL',
      title: 'Identifier les ventes croisées',
      description: 'Analyser les produits achetés ensemble pour proposer des offres complémentaires.',
      priority: 'NORMAL',
      confidencePct: 70,
      sourceData: { productCount: products.length }
    }));
  }

  return opportunities;
}

export function assertOpportunityScope(context, businessId, siteId = null) {
  if (!context?.allowedBusinessIds?.includes(businessId)) {
    throw new Error('Périmètre d’opportunité interdit');
  }
  if (siteId && context.allowedSiteIds && !context.allowedSiteIds.includes(siteId)) {
    throw new Error('Site non autorisé');
  }
  return true;
}

export function approveOpportunity(opportunity) {
  if (!opportunity || opportunity.status !== 'PROPOSED') {
    throw new Error('Opportunité non approuvable dans cet état');
  }
  return { ...opportunity, status: 'APPROVED' };
}

export function rejectOpportunity(opportunity) {
  if (!opportunity || opportunity.status !== 'PROPOSED') {
    throw new Error('Opportunité non rejetable dans cet état');
  }
  return { ...opportunity, status: 'REJECTED' };
}
