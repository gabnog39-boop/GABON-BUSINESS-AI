export const V26_SCENARIO_ROUTES = {
  simulate: 'POST /api/strategy/scenarios/simulate',
  create: 'POST /api/strategy/scenarios',
  list: 'GET /api/strategy/scenarios',
  compare: 'POST /api/strategy/scenarios/compare',
  detail: 'GET /api/strategy/scenarios/:scenarioId'
};
