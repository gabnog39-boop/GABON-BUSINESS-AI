export const V21_DOCUMENT_ROUTES = {
  upload: 'POST /api/documents',
  list: 'GET /api/documents',
  detail: 'GET /api/documents/:documentId',
  analyze: 'POST /api/documents/:documentId/analyze',
  findings: 'GET /api/documents/:documentId/findings',
  confirm: 'POST /api/documents/:documentId/confirm'
};
