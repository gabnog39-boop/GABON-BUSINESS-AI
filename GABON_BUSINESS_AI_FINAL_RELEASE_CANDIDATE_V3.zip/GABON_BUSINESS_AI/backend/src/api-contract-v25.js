export const V25_HEALTH_ROUTES = {
  calculate: 'GET /api/business-health',
  history: 'GET /api/business-health/history',
  detail: 'GET /api/business-health/:scoreId'
};
