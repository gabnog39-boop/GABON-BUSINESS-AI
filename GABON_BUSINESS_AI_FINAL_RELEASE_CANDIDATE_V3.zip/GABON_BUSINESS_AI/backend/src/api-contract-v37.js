export const V37_COMMAND_CENTER_ROUTES = {
  dashboard: 'GET /api/command-center',
  snapshot: 'POST /api/command-center/snapshot',
  brief: 'GET /api/command-center/brief',
  history: 'GET /api/command-center/history'
};
