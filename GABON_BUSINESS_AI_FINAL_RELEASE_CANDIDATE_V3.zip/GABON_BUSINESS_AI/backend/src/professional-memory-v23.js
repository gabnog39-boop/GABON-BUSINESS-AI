const TYPES = new Set([
  'PREFERENCE',
  'OBJECTIVE',
  'DECISION',
  'PROCESS',
  'CUSTOMER_CONTEXT',
  'PRODUCT_CONTEXT',
  'BUSINESS_FACT',
  'AI_INSTRUCTION'
]);

export function normalizeMemory(input = {}) {
  const memoryType = String(input.memoryType || 'BUSINESS_FACT').toUpperCase();
  if (!TYPES.has(memoryType)) throw new Error('Type de mémoire non supporté');

  if (!input.memoryKey) throw new Error('memoryKey obligatoire');

  return {
    memoryType,
    memoryKey: String(input.memoryKey),
    memoryValue: input.memoryValue ?? null,
    confidence: Math.max(0, Math.min(1, Number(input.confidence ?? 1))),
    source: input.source || 'USER',
    active: true
  };
}

export function buildMemoryContext(memories = [], maxItems = 50) {
  return memories
    .filter(m => m && m.active !== false)
    .slice(0, maxItems)
    .map(m => ({
      type: m.memoryType,
      key: m.memoryKey,
      value: m.memoryValue,
      confidence: m.confidence
    }));
}

export function forgetMemory(memory) {
  if (!memory) throw new Error('Mémoire introuvable');
  return { ...memory, active: false, updatedAt: new Date().toISOString() };
}

export function memorySafetyCheck(memory, businessId) {
  if (!memory || memory.businessId !== businessId) {
    throw new Error('Accès mémoire interdit');
  }
  return true;
}
