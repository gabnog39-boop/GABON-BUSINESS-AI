function num(v) {
  return Number.isFinite(Number(v)) ? Number(v) : 0;
}

function pct(v) {
  return 1 + num(v) / 100;
}

export function simulateScenario(baseline = {}, assumptions = {}) {
  const revenue = num(baseline.revenue);
  const expenses = num(baseline.expenses);

  const priceFactor = pct(assumptions.priceChangePct);
  const volumeFactor = pct(assumptions.volumeChangePct);
  const revenueFactor = pct(assumptions.revenueChangePct);
  const expenseFactor = pct(assumptions.expenseChangePct);

  const projectedRevenue =
    revenue * priceFactor * volumeFactor * revenueFactor;

  const projectedExpenses =
    expenses * expenseFactor + num(assumptions.newFixedCosts);

  const operatingResult = projectedRevenue - projectedExpenses;
  const margin = projectedRevenue > 0
    ? (operatingResult / projectedRevenue) * 100
    : 0;

  const warnings = [];
  if (projectedRevenue <= 0) warnings.push('Chiffre d’affaires projeté nul ou négatif.');
  if (operatingResult < 0) warnings.push('Résultat opérationnel projeté négatif.');
  if (num(assumptions.newFixedCosts) > 0)
    warnings.push('Les nouveaux coûts fixes augmentent le point mort.');
  if (num(assumptions.priceChangePct) < -20)
    warnings.push('Baisse de prix importante: vérifier la marge.');
  if (num(assumptions.priceChangePct) > 30)
    warnings.push('Hausse de prix importante: vérifier l’impact commercial.');

  return {
    projectedRevenue,
    projectedExpenses,
    operatingResult,
    margin: Math.round(margin * 100) / 100,
    deltaRevenue: projectedRevenue - revenue,
    deltaExpenses: projectedExpenses - expenses,
    deltaResult: operatingResult - (revenue - expenses),
    warnings
  };
}

export function compareScenarios(results = []) {
  return [...results].sort((a, b) =>
    Number(b.operatingResult || 0) - Number(a.operatingResult || 0)
  );
}

export function buildDecisionSummary(scenario) {
  if (!scenario) throw new Error('Scénario requis');
  const result = Number(scenario.operatingResult || 0);
  const warnings = scenario.warnings || [];

  return {
    status: result >= 0 ? 'FAVORABLE_OR_NEUTRAL' : 'RISK',
    result,
    warnings,
    requiresHumanDecision: true
  };
}
