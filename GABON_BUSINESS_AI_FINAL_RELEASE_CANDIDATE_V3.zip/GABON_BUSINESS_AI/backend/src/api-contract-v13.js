// V13 API contract: dashboard, reports, goals and AI business memory.
// These routes are designed to be mounted behind the existing authenticated,
// paid-access and tenant-isolation middleware.

GET    /api/v13/dashboard/:businessId
POST   /api/v13/reports/:businessId
GET    /api/v13/reports/:businessId
PUT    /api/v13/memory/:businessId
GET    /api/v13/memory/:businessId
POST   /api/v13/goals/:businessId
GET    /api/v13/goals/:businessId

// Security requirement:
// businessId must always be derived/validated against the authenticated
// business membership; never trust a client-supplied businessId alone.
