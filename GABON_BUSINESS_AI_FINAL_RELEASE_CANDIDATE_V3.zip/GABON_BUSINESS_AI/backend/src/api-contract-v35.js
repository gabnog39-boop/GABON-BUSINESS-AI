export const V35_FORECAST_ROUTES = {
  forecast: 'POST /api/forecasts/sales',
  scenarios: 'POST /api/forecasts/sales/scenarios',
  history: 'GET /api/forecasts/sales',
  detail: 'GET /api/forecasts/sales/:forecastId'
};
