
// Canonical V8 API contract.
// Implementations must enforce authentication, tenant isolation and subscription policy.

module.exports = {
  auth: [
    "POST /api/auth/register",
    "POST /api/auth/login",
    "POST /api/auth/logout",
    "GET /api/auth/me"
  ],
  business: [
    "POST /api/businesses",
    "GET /api/businesses/:businessId",
    "GET /api/businesses/:businessId/dashboard"
  ],
  customers: [
    "GET /api/businesses/:businessId/customers",
    "POST /api/businesses/:businessId/customers",
    "PATCH /api/businesses/:businessId/customers/:customerId",
    "DELETE /api/businesses/:businessId/customers/:customerId"
  ],
  products: [
    "GET /api/businesses/:businessId/products",
    "POST /api/businesses/:businessId/products",
    "PATCH /api/businesses/:businessId/products/:productId",
    "DELETE /api/businesses/:businessId/products/:productId"
  ],
  owner: [
    "GET /api/owner/businesses",
    "GET /api/owner/subscriptions",
    "POST /api/owner/subscriptions/:subscriptionId/approve",
    "POST /api/owner/subscriptions/:subscriptionId/reject",
    "POST /api/owner/plans"
  ],
  payments: [
    "POST /api/payments/webhook"
  ],
  ai: [
    "POST /api/businesses/:businessId/ai"
  ]
};
