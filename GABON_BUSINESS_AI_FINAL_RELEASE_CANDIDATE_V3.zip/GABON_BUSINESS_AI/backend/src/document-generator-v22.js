const SUPPORTED_TYPES = new Set([
  'QUOTE',
  'INVOICE',
  'RECEIPT',
  'PURCHASE_ORDER',
  'DELIVERY_NOTE',
  'REPORT',
  'LETTER',
  'CONTRACT'
]);

export function normalizeDocumentType(type) {
  const value = String(type || 'REPORT').toUpperCase();
  if (!SUPPORTED_TYPES.has(value)) throw new Error('Type de document non supporté');
  return value;
}

export function calculateDocumentTotal(items = []) {
  return items.reduce((sum, item) => {
    const quantity = Number(item.quantity || 0);
    const unitPrice = Number(item.unitPrice || 0);
    return sum + quantity * unitPrice;
  }, 0);
}

export function prepareGeneratedDocument(input = {}) {
  const documentType = normalizeDocumentType(input.documentType);
  const items = Array.isArray(input.items) ? input.items : [];
  const total = calculateDocumentTotal(items);

  return {
    documentType,
    title: input.title || `${documentType} — brouillon`,
    customer: input.customer || null,
    supplier: input.supplier || null,
    items,
    totalXaf: total,
    content: input.content || '',
    status: 'DRAFT',
    requiresApproval: true
  };
}

export function approveGeneratedDocument(document, approverId) {
  if (!document || document.status !== 'DRAFT') {
    throw new Error('Seul un brouillon peut être validé');
  }
  if (!approverId) throw new Error('Approbateur obligatoire');

  return {
    ...document,
    status: 'APPROVED',
    approvedBy: approverId,
    approvedAt: new Date().toISOString()
  };
}
