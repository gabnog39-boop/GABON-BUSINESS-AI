export const V31_BENCHMARK_ROUTES = {
  snapshot: 'POST /api/benchmark/snapshots',
  history: 'GET /api/benchmark/history',
  compare: 'POST /api/benchmark/compare',
  summary: 'POST /api/benchmark/summary'
};
