// V15 — Controlled automation engine.
// Automation prepares actions; sensitive actions require confirmation.

function makeAutomationService(pool) {
  const ALLOWED_ACTIONS = new Set([
    'CREATE_REMINDER',
    'PREPARE_CUSTOMER_FOLLOWUP',
    'CREATE_STOCK_ALERT',
    'GENERATE_REPORT',
    'CREATE_TASK'
  ]);

  async function createRule(businessId, rule) {
    if (!ALLOWED_ACTIONS.has(rule.actionType)) {
      throw new Error('Action d’automatisation non autorisée');
    }
    const q = await pool.query(`
      INSERT INTO automation_rules
        (business_id,name,event_type,conditions,action_type,action_payload,
         enabled,requires_confirmation)
      VALUES ($1,$2,$3,$4,$5,$6,$7,$8)
      RETURNING *
    `, [
      businessId, rule.name, rule.eventType, rule.conditions || {},
      rule.actionType, rule.actionPayload || {}, rule.enabled !== false,
      rule.requiresConfirmation !== false
    ]);
    return q.rows[0];
  }

  async function proposeRun(businessId, ruleId, snapshot) {
    const q = await pool.query(`
      SELECT * FROM automation_rules
      WHERE id=$1 AND business_id=$2 AND enabled=true
    `, [ruleId, businessId]);

    if (!q.rows.length) throw new Error('Règle introuvable ou désactivée');

    const rule = q.rows[0];
    const status = rule.requires_confirmation ? 'PROPOSED' : 'PROPOSED';

    const r = await pool.query(`
      INSERT INTO automation_runs
        (rule_id,business_id,status,input_snapshot,result)
      VALUES ($1,$2,$3,$4,$5)
      RETURNING *
    `, [
      rule.id, businessId, status, snapshot || {},
      { actionType: rule.action_type, actionPayload: rule.action_payload }
    ]);
    return r.rows[0];
  }

  async function confirmRun(businessId, runId) {
    const q = await pool.query(`
      SELECT ar.*, au.status
      FROM automation_runs au
      JOIN automation_rules ar ON ar.id=au.rule_id
      WHERE au.id=$1 AND au.business_id=$2
    `, [runId, businessId]);

    if (!q.rows.length) throw new Error('Automatisation introuvable');
    if (q.rows[0].status !== 'PROPOSED') throw new Error('Automatisation non confirmable');

    // Actual execution is intentionally delegated to audited action handlers.
    await pool.query(`
      UPDATE automation_runs
      SET status='CONFIRMED', result=result || $1::jsonb
      WHERE id=$2 AND business_id=$3
    `, [
      JSON.stringify({ confirmationRequired: true, readyForHandler: true }),
      runId, businessId
    ]);

    return { runId, status: 'CONFIRMED', readyForHandler: true };
  }

  return { createRule, proposeRun, confirmRun };
}

module.exports = { makeAutomationService };
