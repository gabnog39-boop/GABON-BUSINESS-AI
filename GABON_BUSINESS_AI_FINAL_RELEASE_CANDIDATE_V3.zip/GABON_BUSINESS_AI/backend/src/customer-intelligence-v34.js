const SEGMENTS = new Set([
  'VIP',
  'FIDÈLE',
  'À_DÉVELOPPER',
  'À_RÉACTIVER',
  'NOUVEAU',
  'STANDARD'
]);

function clamp(n) {
  return Math.max(0, Math.min(100, Number(n) || 0));
}

export function calculateCustomerIntelligence(input = {}) {
  const days = Math.max(0, Number(input.daysSinceLastPurchase || 0));
  const purchases = Math.max(0, Number(input.purchaseCount90d || 0));
  const total = Math.max(0, Number(input.totalPurchases12m || 0));
  const averageOrder = Math.max(0, Number(input.averageOrderValue || 0));

  const recencyScore = clamp(100 - days * 1.5);
  const frequencyScore = clamp(purchases * 8);
  const valueScore = clamp((total / Math.max(averageOrder * 10, 1)) * 50);
  const loyaltyScore = clamp(
    recencyScore * 0.35 +
    frequencyScore * 0.35 +
    valueScore * 0.30
  );

  const churnRiskScore = clamp(100 - (
    recencyScore * 0.55 +
    frequencyScore * 0.25 +
    valueScore * 0.20
  ));

  let segment = 'STANDARD';
  if (loyaltyScore >= 80 && valueScore >= 70) segment = 'VIP';
  else if (loyaltyScore >= 70) segment = 'FIDÈLE';
  else if (churnRiskScore >= 70) segment = 'À_RÉACTIVER';
  else if (valueScore >= 60) segment = 'À_DÉVELOPPER';
  else if (purchases <= 1) segment = 'NOUVEAU';

  if (!SEGMENTS.has(segment)) segment = 'STANDARD';

  return {
    loyaltyScore: Number(loyaltyScore.toFixed(2)),
    valueScore: Number(valueScore.toFixed(2)),
    churnRiskScore: Number(churnRiskScore.toFixed(2)),
    purchaseFrequencyScore: Number(frequencyScore.toFixed(2)),
    recencyScore: Number(recencyScore.toFixed(2)),
    segment,
    explanation: {
      daysSinceLastPurchase: days,
      purchaseCount90d: purchases,
      totalPurchases12m: total,
      averageOrderValue: averageOrder
    }
  };
}

export function buildCustomerActions(score) {
  const actions = [];

  if (score.segment === 'VIP') {
    actions.push('Proposer une offre de fidélisation personnalisée.');
    actions.push('Prioriser le suivi commercial.');
  }

  if (score.segment === 'À_RÉACTIVER') {
    actions.push('Préparer une relance personnalisée.');
    actions.push('Analyser la cause probable de l’inactivité.');
  }

  if (score.segment === 'À_DÉVELOPPER') {
    actions.push('Identifier des ventes croisées pertinentes.');
    actions.push('Proposer une offre complémentaire.');
  }

  if (score.segment === 'NOUVEAU') {
    actions.push('Surveiller le deuxième achat et la conversion.');
  }

  return actions;
}

export function assertCustomerScope(context, businessId, customerId) {
  if (!context?.allowedBusinessIds?.includes(businessId)) {
    throw new Error('Entreprise non autorisée');
  }
  if (context.allowedCustomerIds && !context.allowedCustomerIds.includes(customerId)) {
    throw new Error('Client non autorisé');
  }
  return true;
}
