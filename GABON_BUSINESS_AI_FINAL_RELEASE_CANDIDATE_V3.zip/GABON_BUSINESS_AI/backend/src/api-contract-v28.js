export const V28_AUTOMATION_ROUTES = {
  createRule: 'POST /api/automation/rules',
  listRules: 'GET /api/automation/rules',
  updateRule: 'PATCH /api/automation/rules/:ruleId',
  disableRule: 'POST /api/automation/rules/:ruleId/disable',
  evaluate: 'POST /api/automation/rules/:ruleId/evaluate',
  confirm: 'POST /api/automation/executions/:executionId/confirm',
  history: 'GET /api/automation/executions'
};
