
// Platform-owner actions are intentionally isolated from ordinary business roles.

const ALLOWED = new Set([
  "VIEW_BUSINESSES",
  "VIEW_SUBSCRIPTIONS",
  "APPROVE_SUBSCRIPTION",
  "REJECT_SUBSCRIPTION",
  "MANAGE_PLANS",
  "MANAGE_PLATFORM_VERSIONS",
  "VIEW_PLATFORM_REVENUE",
  "VIEW_AUDIT_LOGS"
]);

function assertOwnerAction(platformRole, action) {
  if (platformRole !== "OWNER" || !ALLOWED.has(action)) {
    const err = new Error("OWNER_ACTION_FORBIDDEN");
    err.statusCode = 403;
    throw err;
  }
  return true;
}

module.exports = { assertOwnerAction };
