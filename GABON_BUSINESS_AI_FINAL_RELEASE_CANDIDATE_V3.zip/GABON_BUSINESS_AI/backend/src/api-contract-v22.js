export const V22_DOCUMENT_GENERATOR_ROUTES = {
  prepare: 'POST /api/documents/generate',
  list: 'GET /api/documents/generated',
  detail: 'GET /api/documents/generated/:documentId',
  approve: 'POST /api/documents/generated/:documentId/approve',
  exportPdf: 'POST /api/documents/generated/:documentId/export/pdf',
  send: 'POST /api/documents/generated/:documentId/send'
};
