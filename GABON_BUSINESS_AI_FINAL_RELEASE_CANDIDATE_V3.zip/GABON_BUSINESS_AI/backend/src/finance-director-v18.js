// V18 — Directeur Finance IA
// Management analysis only; not certified accounting or financial advice.

function makeFinanceDirector(pool) {
  async function snapshot(businessId) {
    const q = await pool.query(`
      SELECT
        COALESCE((SELECT SUM(amount) FROM payments WHERE business_id=$1),0) AS cash_received,
        COALESCE((SELECT SUM(amount) FROM expenses WHERE business_id=$1),0) AS expenses,
        COALESCE((SELECT SUM(total_amount) FROM purchase_orders
                  WHERE business_id=$1 AND status IN ('RECEIVED','PARTIAL')),0) AS purchases,
        COALESCE((SELECT SUM(total) FROM invoices WHERE business_id=$1),0) AS invoiced
    `, [businessId]);

    const r = q.rows[0];
    const cash = Number(r.cash_received);
    const expenses = Number(r.expenses);
    const purchases = Number(r.purchases);
    const invoiced = Number(r.invoiced);

    return {
      cashReceived: cash,
      expenses,
      purchases,
      invoiced,
      receivables: Math.max(invoiced - cash, 0),
      estimatedOperatingResult: cash - expenses - purchases,
      cashCoverageRatio: expenses + purchases > 0
        ? cash / (expenses + purchases)
        : null
    };
  }

  async function analysis(businessId) {
    const s = await snapshot(businessId);
    const alerts = [];

    if (s.receivables > 0) {
      alerts.push({
        type: 'RECEIVABLES',
        severity: 'HIGH',
        title: 'Créances clients à surveiller',
        reason: `Montant estimé des créances : ${s.receivables}`
      });
    }

    if (s.cashCoverageRatio !== null && s.cashCoverageRatio < 1) {
      alerts.push({
        type: 'CASH_FLOW',
        severity: 'HIGH',
        title: 'Pression sur la trésorerie',
        reason: 'Les encaissements enregistrés ne couvrent pas les sorties d’exploitation enregistrées.'
      });
    }

    if (s.estimatedOperatingResult < 0) {
      alerts.push({
        type: 'RESULT',
        severity: 'HIGH',
        title: 'Résultat de gestion négatif',
        reason: 'Les sorties enregistrées dépassent les encaissements.'
      });
    }

    return {
      snapshot: s,
      alerts,
      disclaimer: 'Indicateurs de gestion basés sur les données disponibles; ils ne constituent pas une comptabilité certifiée.'
    };
  }

  async function saveAlerts(businessId, alerts) {
    const saved = [];
    for (const a of alerts) {
      const q = await pool.query(`
        INSERT INTO finance_alerts
          (business_id,alert_type,severity,title,reason,payload)
        VALUES ($1,$2,$3,$4,$5,$6)
        RETURNING *
      `, [businessId, a.type, a.severity, a.title, a.reason, a.payload || {}]);
      saved.push(q.rows[0]);
    }
    return saved;
  }

  return { snapshot, analysis, saveAlerts };
}

module.exports = { makeFinanceDirector };
