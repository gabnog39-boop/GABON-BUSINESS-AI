export function analyzeMarketing({ customers = [], invoices = [], products = [] }) {
  const recommendations = [];

  const customerCount = customers.length;
  const invoiceCount = invoices.length;

  if (customerCount === 0) {
    recommendations.push({
      type: 'ACQUISITION',
      title: 'Lancer une campagne d’acquisition',
      rationale: 'Aucun client n’est encore enregistré.',
      proposedAction: 'Préparer une offre de bienvenue et une campagne ciblée.',
      requiresConfirmation: true
    });
  } else {
    recommendations.push({
      type: 'FIDELISATION',
      title: 'Renforcer la fidélisation',
      rationale: `${customerCount} client(s) sont enregistrés.`,
      proposedAction: 'Identifier les clients inactifs et préparer une relance personnalisée.',
      requiresConfirmation: true
    });
  }

  if (invoiceCount > 0) {
    recommendations.push({
      type: 'PROMOTION',
      title: 'Exploiter les ventes existantes',
      rationale: `${invoiceCount} facture(s) fournissent une base commerciale exploitable.`,
      proposedAction: 'Identifier les produits/services les plus vendus et proposer une offre ciblée.',
      requiresConfirmation: true
    });
  }

  if (products.length > 0) {
    recommendations.push({
      type: 'CROSS_SELL',
      title: 'Développer les ventes complémentaires',
      rationale: `${products.length} produit(s)/service(s) sont disponibles.`,
      proposedAction: 'Préparer des offres groupées et des recommandations complémentaires.',
      requiresConfirmation: true
    });
  }

  return {
    summary: 'Analyse marketing générée à partir des données commerciales disponibles.',
    recommendations
  };
}

export function buildMarketingCampaign({ name, objective, channel, audience, budgetXaf = 0 }) {
  if (!name || !objective || !channel) {
    throw new Error('name, objective et channel sont obligatoires');
  }

  return {
    name,
    objective,
    channel,
    audience: audience || null,
    budgetXaf: Number(budgetXaf) || 0,
    status: 'DRAFT',
    requiresConfirmation: Number(budgetXaf) > 0
  };
}
