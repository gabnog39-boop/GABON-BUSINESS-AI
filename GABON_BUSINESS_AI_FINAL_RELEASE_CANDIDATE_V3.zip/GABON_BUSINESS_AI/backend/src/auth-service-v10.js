
const crypto = require("crypto");
const { pool } = require("./db");

function hashPassword(password) {
  const salt = crypto.randomBytes(16);
  const derived = crypto.scryptSync(password, salt, 64);
  return `scrypt$${salt.toString("base64url")}$${derived.toString("base64url")}`;
}

function verifyPassword(password, encoded) {
  const [scheme, saltB64, hashB64] = String(encoded).split("$");
  if (scheme !== "scrypt" || !saltB64 || !hashB64) return false;
  const derived = crypto.scryptSync(password, Buffer.from(saltB64, "base64url"), 64);
  const expected = Buffer.from(hashB64, "base64url");
  return expected.length === derived.length && crypto.timingSafeEqual(expected, derived);
}

function tokenHash(token) {
  return crypto.createHash("sha256").update(token).digest("hex");
}

async function createSession(userId, days = 30) {
  const token = crypto.randomBytes(32).toString("base64url");
  const expires = new Date(Date.now() + days * 86400000);
  await pool.query(
    "INSERT INTO sessions(user_id, token_hash, expires_at) VALUES($1,$2,$3)",
    [userId, tokenHash(token), expires]
  );
  return { token, expires_at: expires.toISOString() };
}

async function getSession(token) {
  if (!token) return null;
  const q = await pool.query(
    `SELECT s.user_id,s.expires_at,u.email,u.role,u.active
     FROM sessions s JOIN platform_users u ON u.id=s.user_id
     WHERE s.token_hash=$1 AND s.expires_at > now() AND u.active=true`,
    [tokenHash(token)]
  );
  return q.rows[0] || null;
}

async function revokeSession(token) {
  if (!token) return;
  await pool.query("DELETE FROM sessions WHERE token_hash=$1", [tokenHash(token)]);
}

module.exports = { hashPassword, verifyPassword, createSession, getSession, revokeSession };
