const SPECIALISTS = {
  FINANCE: ['cashflow', 'receivables', 'expenses', 'profitability', 'payments'],
  COMMERCIAL: ['sales', 'customers', 'prospects', 'followup', 'opportunities'],
  STOCK: ['inventory', 'stock', 'reorder', 'products', 'purchases'],
  MARKETING: ['campaign', 'promotion', 'retention', 'acquisition'],
  DOCUMENTS: ['invoice', 'quote', 'receipt', 'contract', 'report', 'letter'],
  MEMORY: ['preference', 'objective', 'decision', 'procedure', 'context'],
  STRATEGY: ['scenario', 'simulation', 'price', 'hiring', 'agency', 'forecast']
};

const SENSITIVE_ACTIONS = new Set([
  'CREATE_INVOICE', 'CREATE_QUOTE', 'RECORD_PAYMENT',
  'CREATE_EXPENSE', 'CREATE_PURCHASE_ORDER', 'SEND_DOCUMENT',
  'CHANGE_SUBSCRIPTION', 'DELETE_DATA'
]);

export function detectSpecialist(input = {}) {
  const text = String(input.text || '').toLowerCase();

  const scores = Object.fromEntries(
    Object.entries(SPECIALISTS).map(([name, terms]) => [
      name,
      terms.reduce((score, term) => score + (text.includes(term) ? 1 : 0), 0)
    ])
  );

  const ordered = Object.entries(scores).sort((a, b) => b[1] - a[1]);
  return ordered[0][1] > 0 ? ordered[0][0] : 'GENERAL';
}

export function buildDirectorPlan(input = {}) {
  const specialist = detectSpecialist(input);
  const action = input.action || null;
  const sensitive = SENSITIVE_ACTIONS.has(String(action || '').toUpperCase());

  return {
    specialist,
    action,
    sensitive,
    requiresConfirmation: sensitive,
    contextScopes: specialist === 'GENERAL'
      ? ['dashboard', 'memory']
      : [specialist.toLowerCase(), 'memory'],
    status: sensitive ? 'AWAITING_CONFIRMATION' : 'READY'
  };
}

export function mergeSpecialistResults(results = []) {
  return {
    specialistsUsed: results.map(r => r.specialist).filter(Boolean),
    findings: results.flatMap(r => Array.isArray(r.findings) ? r.findings : []),
    recommendations: results.flatMap(r =>
      Array.isArray(r.recommendations) ? r.recommendations : []
    )
  };
}

export function confirmDirectorAction(plan, confirmation) {
  if (!plan) throw new Error('Plan IA manquant');
  if (!plan.requiresConfirmation) return { ...plan, status: 'READY' };
  if (confirmation !== true) throw new Error('Confirmation humaine obligatoire');
  return { ...plan, status: 'CONFIRMED' };
}
