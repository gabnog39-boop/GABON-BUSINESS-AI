export const V23_MEMORY_ROUTES = {
  create: 'POST /api/memory',
  list: 'GET /api/memory',
  update: 'PATCH /api/memory/:memoryId',
  deactivate: 'POST /api/memory/:memoryId/deactivate',
  context: 'GET /api/memory/context'
};
