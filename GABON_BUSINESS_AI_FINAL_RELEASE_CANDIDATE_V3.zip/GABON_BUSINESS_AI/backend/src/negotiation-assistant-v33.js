const STYLES = new Set([
  'VALUE',
  'RELATIONSHIP',
  'PRICE',
  'COMPETITIVE',
  'LONG_TERM'
]);

export function prepareNegotiation(input = {}) {
  if (!input.businessId) throw new Error('businessId obligatoire');
  if (!input.objective) throw new Error('Objectif obligatoire');

  const style = String(input.style || 'VALUE').toUpperCase();
  if (!STYLES.has(style)) throw new Error('Style de négociation invalide');

  const target = numberOrNull(input.targetPrice);
  const minimum = numberOrNull(input.minimumPrice);
  const proposed = numberOrNull(input.proposedPrice);

  if (minimum !== null && target !== null && minimum > target) {
    throw new Error('Le prix minimum ne peut pas dépasser la cible');
  }

  const room = target !== null && minimum !== null
    ? target - minimum
    : null;

  return {
    businessId: input.businessId,
    customerId: input.customerId || null,
    objective: String(input.objective),
    targetPrice: target,
    minimumPrice: minimum,
    proposedPrice: proposed,
    currency: input.currency || 'XAF',
    style,
    negotiationRoom: room,
    status: 'DRAFT'
  };
}

export function generateNegotiationPlan(context = {}) {
  const plan = [];
  const margin = Number(context.marginPct || 0);
  const customerValue = Number(context.customerValue || 0);
  const objections = Array.isArray(context.objections) ? context.objections : [];

  if (margin > 0 && margin < 15) {
    plan.push({
      type: 'PROTECT_MARGIN',
      advice: 'Éviter une remise importante et renforcer la valeur proposée.'
    });
  }

  if (customerValue > 0) {
    plan.push({
      type: 'RELATIONSHIP_VALUE',
      advice: 'Mettre en avant les avantages liés à une relation commerciale durable.'
    });
  }

  if (objections.length) {
    for (const objection of objections.slice(0, 10)) {
      plan.push({
        type: 'OBJECTION_RESPONSE',
        objection: String(objection),
        advice: 'Reconnaître le besoin, clarifier le point bloquant et proposer une réponse fondée sur la valeur.'
      });
    }
  }

  plan.push({
    type: 'CONFIRMATION',
    advice: 'Faire valider les conditions finales par un utilisateur autorisé avant engagement.'
  });

  return plan;
}

export function assertNegotiationScope(context, businessId) {
  if (!context?.allowedBusinessIds?.includes(businessId)) {
    throw new Error('Périmètre de négociation interdit');
  }
  return true;
}

export function approveNegotiation(session) {
  if (!session || session.status !== 'DRAFT') {
    throw new Error('Session non approuvable dans cet état');
  }
  return { ...session, status: 'APPROVED' };
}

function numberOrNull(value) {
  if (value === undefined || value === null || value === '') return null;
  const n = Number(value);
  if (!Number.isFinite(n) || n < 0) throw new Error('Montant invalide');
  return n;
}
