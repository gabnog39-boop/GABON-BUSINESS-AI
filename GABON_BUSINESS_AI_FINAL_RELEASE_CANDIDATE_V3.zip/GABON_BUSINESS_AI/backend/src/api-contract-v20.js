export const V20_MARKETING_ROUTES = {
  analyze: 'POST /api/ai/marketing/analyze',
  recommendations: 'GET /api/marketing/recommendations',
  campaigns: 'GET /api/marketing/campaigns',
  createCampaign: 'POST /api/marketing/campaigns',
  prepareMessage: 'POST /api/marketing/messages/prepare'
};
