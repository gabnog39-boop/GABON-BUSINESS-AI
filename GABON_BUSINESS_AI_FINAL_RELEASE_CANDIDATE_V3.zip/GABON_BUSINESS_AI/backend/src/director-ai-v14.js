// GABON BUSINESS AI V14 — Directeur IA
// Decision-support layer. Sensitive actions must require explicit confirmation.

function makeDirectorAI({ v13Service }) {
  async function buildContext(businessId) {
    const [dashboard, memory] = await Promise.all([
      v13Service.dashboard(businessId),
      v13Service.getMemory(businessId, 30)
    ]);
    return { dashboard, memory };
  }

  function analyze(context) {
    const { dashboard, memory } = context;
    const recommendations = [];

    if (dashboard.receivables > 0) {
      recommendations.push({
        priority: "HIGH",
        type: "CASH_COLLECTION",
        title: "Relancer les créances clients",
        reason: `Créances estimées : ${dashboard.receivables}`,
        action: "Préparer une liste de relance et des messages."
      });
    }

    if (dashboard.expenses + dashboard.purchases > dashboard.paid && dashboard.paid > 0) {
      recommendations.push({
        priority: "HIGH",
        type: "CASH_FLOW",
        title: "Surveiller la trésorerie",
        reason: "Les sorties enregistrées dépassent les encaissements.",
        action: "Analyser les dépenses et achats avant tout nouvel engagement."
      });
    }

    if (memory.length === 0) {
      recommendations.push({
        priority: "MEDIUM",
        type: "MEMORY",
        title: "Construire la mémoire métier",
        reason: "Aucune mémoire métier importante n'est encore enregistrée.",
        action: "Enregistrer les préférences, objectifs et règles de l'entreprise."
      });
    }

    return {
      summary: "Analyse de gestion générée à partir des données disponibles.",
      recommendations
    };
  }

  return {
    async analyzeBusiness(businessId) {
      return analyze(await buildContext(businessId));
    },

    async command(businessId, commandText) {
      const text = String(commandText || "").trim();
      if (!text) throw new Error("Commande vide");

      // V14 deliberately produces an action plan instead of executing
      // destructive or financial actions without confirmation.
      return {
        intent: "BUSINESS_ASSISTANCE",
        command: text,
        requiresConfirmation: true,
        plan: [
          "Comprendre la demande",
          "Vérifier les données de l'entreprise",
          "Préparer l'action",
          "Demander confirmation si l'action modifie des données, crée une facture ou déclenche un paiement"
        ],
        analysis: await this.analyzeBusiness(businessId)
      };
    }
  };
}

module.exports = { makeDirectorAI };
